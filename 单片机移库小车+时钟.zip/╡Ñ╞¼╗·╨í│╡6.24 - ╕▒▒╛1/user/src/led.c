#include "led.h"


void LedInit(void)
{
	P3M1 &= ~(1<<4);
	P3M0 &= ~(1<<4);
	
	P5M0 &= ~(1<<0);
	P5M1 &= ~(1<<0);
	
	P34 = 1;
	P50 = 1;
}


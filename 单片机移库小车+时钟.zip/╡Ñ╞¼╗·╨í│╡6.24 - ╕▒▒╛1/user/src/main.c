#include "stc15.h"
#include "led.h"
#include "timer.h"
#include "uart.h"
#include "voice.h"
#include "sr04.h"
#include "oled.h"
#include <intrins.h>
#include <stdio.h>
#include <stdlib.h>
#include "motor.h"
#include "encode.h"
#include "battery.h"
#include "pid.h"
#include "hc05.h"
#include <string.h>

void TrackInit()
{
	P2M1 &=~(1<<7);P2M0 &=~(1<<7);
	P4M1 |=~(1<<2);P4M0 &=~(1<<2);
}

char str1[35];
char str2[35];
char str3[35];
float v;
float s=0.0;
char flag=0,flag1=0;//ǰ�����˱�־
//int state=0;

void hc05()
	{
		if ( btReady == 1)
			{	
			printf("%c%c%c\r\n",appData[0],appData[1],appData[2]);
			if( appData[0]=='O' && appData[1]=='N' ) {	//��һ���ֽ�ΪO,�ڶ����ֽ�ΪN,�������ֽ�Ϊ������
				switch ( appData[2] ) {
				case UP:
						MotorForward();
						break;
				case DOWN:
						MotorBackward();
						break;
				case LEFT:
						MotorLeft();
						break;
				case RIGHT:
						MotorRight();
						break;
				case STOP:
						MotorStop();
						break;
				case ONE:
						Car_ChangeSpeed(25);
						PidChangeSv(ONE_SV);
						break;
				case TWO:
						Car_ChangeSpeed(50);
						PidChangeSv(TWO_SV);
						break;
				case THREE:
						Car_ChangeSpeed(75);
						PidChangeSv(THREE_SV);
						break;
				case FOUR:
						Car_ChangeSpeed(100);
						PidChangeSv(FOUR_SV);
						break;
				}
			}
			btReady = 0;
			btCount = 0;
			memset(appData,0,3);
		}
	}
	


int main()
{
	
	EA = 1;
	LedInit();
	Timer0Init();
	Uart1Init();
	OLED_Init();
	Sr04Init();
	EncodeInit();
	MotorInit();
	ADCInit();
	PidInit();
	TrackInit();
	
	//HC05Init();
	//VoiceInit();
	
//	LeftFront_Wide = 20;//75 
//	LeftRear_Wide = 20;//72
//	RightFront_Wide = 20;//70
//	RightRear_Wide = 20;//76
	
//	LeftFront_ChangeSpeed(LeftFront_Wide);
//	LeftRear_ChangeSpeed(LeftRear_Wide);
//	RightFront_ChangeSpeed(RightFront_Wide);	
//	RightRear_ChangeSpeed(RightRear_Wide);	
	
	//MotorForward();
	
	printf("start\r\n");
	OledDisplayString(0,0,"�ٶ�:");
	OledDisplayString(2,0,"����:");
	OledDisplayString(4,0,"����:");
	while(1)
	{
		
		/* �ַ���ת�� */
		sprintf(str1,"%4.2frad/s",leftFrontSpeed);
		sprintf(str2,"%8.2fv",v);
		sprintf(str3,"%7.2fcm",s);//2.2
		/* OLED��ʾ */
		OledDisplayString(0,40,str1);
		OledDisplayString(2,40,str2);
		OledDisplayString(4,40,str3);
		/* ������ʾ */
		printf("i:%f,%f,%f,%f\n",leftFrontSpeed,leftRearSpeed,rightFrontSpeed,rightRearSpeed);
		printf("leftFrontSpeed = %f\r\n",leftFrontSpeed);
		printf("leftRearSpeed = %f\r\n",leftRearSpeed);
		printf("rightFrontSpeed = %f\r\n",rightFrontSpeed);
		printf("rightRearSpeed = %f\r\n",rightRearSpeed);
		
		
		
		v=GetBarPower();
//		if(v>100.0)
//	{
//		v=0.0;
//	}
		s=Sr04Measure();
		
		
//	if(s>1000.0)
//	{
//		s=0.0;
//	}
		//hc05();
	}
}

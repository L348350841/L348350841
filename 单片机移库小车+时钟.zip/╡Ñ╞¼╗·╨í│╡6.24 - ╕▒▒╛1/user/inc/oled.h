#ifndef __OLED_H__
#define __OLED_H__

#include "stc15.h"
#include "spi.h"


#define OLED_DC		P53
#define	OLED_CS		P04
#define OLED_RES 	P52

#define OLED_ReadWriteByte(dat)	\
		do { SpiReadWrite(dat); } while(0)

	

void OLED_IO_Init(void);
void OLED_WR_Com(char Com);
void OLED_WR_Dat(char Dat);
void OLED_Init(void);
void OLED_Clear(void);
void OLED_Clear_s(void);
void OLED_Setpos(int page,int colum);
		
void OledDisplayAscii(char page,char colum,char ch);
void OledDisplayChinese(char page,char colum,unsigned char *font);
void OledDisplayString(char page,char colum,unsigned char *str);

#endif
#ifndef _TIMER_H
#define _TIMER_H

#include "stc15.h"
#include "sr04.h"

void Timer0Init(void);
void Delaynms(int num);
void Timer1Init(void);


#endif
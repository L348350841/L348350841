#ifndef _UART_H
#define _UART_H

#include "stc15.h"
#include "voice.h"

#define S3RI  		0x01    //S3CON.0
#define S3TI  		0x02    //S3CON.1
#define S3_S  		0x02	//P3_S.1

void Uart1Init(void);
void Uart1SendData(char dat);
void Uart3Init(void);
void Uart3SendData(char dat);


#endif
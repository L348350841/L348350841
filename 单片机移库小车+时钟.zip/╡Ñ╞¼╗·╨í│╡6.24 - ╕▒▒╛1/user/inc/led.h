#ifndef _LED_H
#define _LED_H

#include "stc15.h"

#define led1(x)		(x?(P34=0):(P34=1))
#define led2(x)		(x?(P50=0):(P50=1))

void LedInit(void);
	
#endif
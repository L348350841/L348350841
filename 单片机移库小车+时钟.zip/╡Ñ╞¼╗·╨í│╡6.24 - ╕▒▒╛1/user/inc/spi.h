#ifndef _SPI_H
#define _SPI_H

#include "stc15.h"

#define SPI_S1			0x08//P_SW1.3
#define SPI_S0			0x04//P_SW1.2

#define SSIG     	   	0x80//SPCTL.7                                 
#define SPEN      		0x40//SPCTL.6                                 
#define DORD        	0x20//SPCTL.5                                 
#define MSTR        	0x10//SPCTL.4                                 
#define CPOL        	0x08//SPCTL.3                                 
#define CPHA        	0x04//SPCTL.2 

#define SPIF        	0x80//SPSTAT.7                                
#define WCOL        	0x40//SPSTAT.6 

#define ESPI        	0x02//IE2.1


void SpiInit(void);
u8 SpiReadWrite(u8 dat);

#endif


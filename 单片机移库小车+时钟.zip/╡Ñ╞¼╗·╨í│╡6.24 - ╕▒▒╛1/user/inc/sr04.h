#ifndef _SR04_H
#define _SR04_H

#include "stc15.h"
#include "timer.h"
#include <stdio.h>

#define TRIG		P06
#define ECHO		P07

extern unsigned int timerIrqNum;
extern float s;

void Sr04Init(void);
void Sr04Trig(void);
unsigned long Sr04Echo(void);
float Sr04Measure(void);

#endif
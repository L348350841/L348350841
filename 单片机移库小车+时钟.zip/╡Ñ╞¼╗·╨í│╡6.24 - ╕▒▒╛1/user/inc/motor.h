#ifndef _MOTOR_H
#define _MOTOR_H

#include "stc15.h"

#define PWM2345_S		0x10//P_SW2.4

#define LEFT_STBY		P64
#define RIGHT_STBY		P74

#define LEFT_AIN1		P60	
#define LEFT_AIN2		P61
#define LEFT_PWMA		P37//PWM2

#define LEFT_BIN1		P62
#define LEFT_BIN2		P63
#define LEFT_PWMB		P21//PWM3

#define RIGHT_AIN1		P70
#define RIGHT_AIN2		P71
#define RIGHT_PWMA		P22//PWM4

#define RIGHT_BIN1		P72
#define RIGHT_BIN2		P73
#define RIGHT_PWMB		P23//PWM5

#define CYCLE   1106L	//����PWM����Ϊ10KHZ(���ֵΪ32767)
#define DUTY    100L	//����ռ�ձ�Ϊ100%

#define LeftFront_Forward()		do { LEFT_AIN1 = 0;LEFT_AIN2 = 1; } while(0)
#define LeftFront_Backward()	do { LEFT_AIN1 = 1;LEFT_AIN2 = 0; } while(0)
#define LeftFront_Stop()		do { LEFT_AIN1 = 0;LEFT_AIN2 = 0; } while(0)

#define LeftRear_Forward()		do { LEFT_BIN2 = 0;LEFT_BIN1 = 1; } while(0)
#define LeftRear_Backward()		do { LEFT_BIN2 = 1;LEFT_BIN1 = 0; } while(0)
#define LeftRear_Stop()			do { LEFT_BIN2 = 0;LEFT_BIN1 = 0; } while(0)

#define RightFront_Forward()	do { RIGHT_AIN1= 1;RIGHT_AIN2= 0; } while(0)
#define RightFront_Backward()	do { RIGHT_AIN1= 0;RIGHT_AIN2= 1; } while(0)
#define RightFront_Stop()		do { RIGHT_AIN1= 0;RIGHT_AIN2= 0; } while(0)

#define RightRear_Forward()		do { RIGHT_BIN2= 1;RIGHT_BIN1= 0; } while(0)
#define RightRear_Backward()	do { RIGHT_BIN2= 0;RIGHT_BIN1= 1; } while(0)
#define RightRear_Stop()		do { RIGHT_BIN2= 0;RIGHT_BIN1= 0; } while(0)

#define LeftFront_ChangeSpeed(x)	LEFT_PWMA_SetPwmWide(x)
#define LeftRear_ChangeSpeed(x)		LEFT_PWMB_SetPwmWide(x)
#define RightFront_ChangeSpeed(x)	RIGHT_PWMB_SetPwmWide(x)
#define RightRear_ChangeSpeed(x)	RIGHT_PWMA_SetPwmWide(x)

#define Car_ChangeSpeed(x)	\
	do { LeftFront_ChangeSpeed(x);LeftRear_ChangeSpeed(x);RightFront_ChangeSpeed(x);RightRear_ChangeSpeed(x); } while(0)

extern unsigned char LeftFront_Wide;
extern unsigned char LeftRear_Wide;
extern unsigned char RightFront_Wide;
extern unsigned char RightRear_Wide;



void PwmInit(void);
void MotorInit(void);
void MotorForward(void);
void MotorBackward(void);
void MotorStop(void);
void MotorLeft(void);
void MotorRight(void);
void MotorLeft_S(void);
void MotorRight_S(void);




void LEFT_PWMA_SetPwmWide(unsigned short Wide);	//������ǰ�ֵ�PWMռ�ձ�
void LEFT_PWMB_SetPwmWide(unsigned short Wide);	//��������ֵ�PWMռ�ձ�
void RIGHT_PWMA_SetPwmWide(unsigned short Wide);//�����Һ��ֵ�PWMռ�ձ�
void RIGHT_PWMB_SetPwmWide(unsigned short Wide);//������ǰ�ֵ�PWMռ�ձ�

#endif
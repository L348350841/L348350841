#ifndef _TASK_H
#define _TASK_H

#define infrared_LLL  P43
#define infrared_LL   P42
#define infrared_L    P41
#define infrared_R    P25
#define infrared_RR   P26
#define infrared_RRR  P27

extern unsigned int timess;

void task1();
void task2();

#endif

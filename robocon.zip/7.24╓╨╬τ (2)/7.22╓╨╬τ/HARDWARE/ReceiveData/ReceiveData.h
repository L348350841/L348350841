#ifndef _ReceiveData_H_
#define _ReceiveData_H_
#include "stm32f4xx.h"


void ReceiveDataFormNRF(void);


//void Sbus_Data_Count(uint8_t *buf);
//u32 change(u16 num);


#endif


// 头文件
#include <stdio.h>
#include <string.h>
#include <pthread.h>
#include <gtk/gtk.h>

#include <stdlib.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include "sqlite3.h"
#include "rfid_lib.h"

//串口号
#if 0
    #define UART_DEV    "/dev/ttyUSB0"
#else
    #define UART_DEV    "/dev/ttySAC2"
#endif

sqlite3 * db =NULL;;
sqlite3 * db_y =NULL;;
//-----------登录与注册界面----------------------
    GtkWidget * entry;
    GtkWidget * entry1;

    GtkWidget * entry_1;
    GtkWidget * entry_11;
    GtkWidget * entry_12;

    GtkWidget * entry_2;
    GtkWidget * entry_21;
    GtkWidget * entry_22;

    GtkWidget * label;
    GtkWidget * label1;
    GtkWidget * label2;
    GtkWidget * label3;
    GtkWidget * label4;

    GtkWidget * label_1;
    GtkWidget * label_11;
    GtkWidget * label_12;
    GtkWidget * label_13;
    GtkWidget * label_14;
    GtkWidget * label_15;

    GtkWidget * label_2;
    GtkWidget * label_21;
    GtkWidget * label_22;
    GtkWidget * label_23;
    GtkWidget * label_24;
    GtkWidget * label_25;


    GtkWidget * window;
    GtkWidget * window1;
    GtkWidget * window2;
    GtkWidget * window3;
    // GtkWidget * window4;
    // GtkWidget * window5;
    // GtkWidget * window;
//-----------主页界面----------------------
    GtkWidget * label_g;
    GtkWidget * label_g1;
    GtkWidget * label_g2;
    GtkWidget * label_g3;
    GtkWidget * label_g4;
    GtkWidget * label_g5;
//-----------图书借阅界面----------------------
    GtkWidget * window_y;
    GtkWidget * window_y1;
    GtkWidget * window_y2;
    GtkWidget * window_y3;
    GtkWidget * window_y4;
    GtkWidget * window_y5;

    GtkWidget * entry_y;
    GtkWidget * entry_y1;
    GtkWidget * entry_y2;
    GtkWidget * entry_y3;
    GtkWidget * entry_y4;
    GtkWidget * entry_y5;
    GtkWidget * label_y;
    GtkWidget * label_y1;
    GtkWidget * label_y2;
    GtkWidget * label_y3;
    GtkWidget * label_y4;
    GtkWidget * label_y5;
    GtkWidget * label_y6;
    GtkWidget * label_y7;
    GtkWidget * label_y8;
    GtkWidget * label_y9;
    GtkWidget * label_y10;
    GtkWidget * label_y11;
    GtkWidget * label_y12;
    GtkWidget * label_y13;
    GtkWidget * label_y14;
    GtkWidget * label_y15;
    GtkWidget * label_y16;
    GtkWidget * label_y17;
    GtkWidget * label_y18;
    GtkWidget * label_y19;
    GtkWidget * label_y20;
    GtkWidget * label_y21;

    GtkWidget * label_y22;
    GtkWidget * label_y23;
    GtkWidget * label_y24;
    GtkWidget * label_y25;
    GtkWidget * label_y26;
    GtkWidget * label_y27;
    GtkWidget * label_y28;
    GtkWidget * label_y29;
    GtkWidget * label_y30;
    GtkWidget * label_y31;
    GtkWidget * label_y32;
    GtkWidget * label_y33;

    GtkWidget * button_y1;
    GtkWidget * button_y2;
    GtkWidget * button_y3;
    GtkWidget * button_y4;
    GtkWidget * button_y5;
    GtkWidget * button_y6;
    GtkWidget * button_y7;
    GtkWidget * button_y8;
    GtkWidget * button_y9;
    GtkWidget * button_y10;
    GtkWidget * button_y11;
    GtkWidget * button_y12;
    GtkWidget * button_y13;
    GtkWidget * button_y14;
    GtkWidget * button_y15;
    GtkWidget * button_y16;
    GtkWidget * button_y17;
    GtkWidget * button_y18;
    GtkWidget * button_y19;
    GtkWidget * button_y20;
    GtkWidget * button_y21;
    GtkWidget * image_y;
    GtkWidget * fixed_y;
    GtkWidget * fixed_y1;
    GtkWidget * fixed_y2;
    GtkWidget * fixed_y3;
    GtkWidget * fixed_y4;
    GtkWidget * fixed_y5;

    GtkWidget * window_y6;
    GtkWidget * fixed_y6;
    GtkWidget * button_y22;
    GtkWidget * button_y23;

//-----------座位预约界面----------------------
        GtkWidget * entry_x;		GtkWidget * entry_x1;

        GtkWidget * button_x20;	GtkWidget * button_x21;
        GtkWidget * button_x1;	
        GtkWidget * img_btn_x1;GtkWidget *img_btn_x2;GtkWidget *img_btn_x3;GtkWidget *img_btn_x4;GtkWidget *img_btn_x5;GtkWidget *img_btn_x6;GtkWidget *img_btn_x10;
        GtkWidget * label_x;		GtkWidget * label_x9;		GtkWidget * label_x10;		GtkWidget * label_time_x;

        GtkWidget * window_x;		GtkWidget * window_x1;	GtkWidget * window_x2;

        // -------------------------------------
        //-------------------------------------是否冲突
        // --------------------------------------------
    guint timer_x; //定时

    gint count_x1 = 1,	count_x2 = 2,		count_x3 = 3, 	count_x4 = 4,		count_x5 = 5,		count_x6 = 6,
        count_x7 = 7,	count_x8 = 8,		count_x9 = 9,		count_x10 = 10,	count_x11 = 11,	count_x12 = 12,	
        count_x13 = 13,	count_x14 = 14,	count_x15 = 15,	count_x16 = 16,	count_x17 = 17,	count_x18 = 18;
    char num_x = 0, flag_num_x=0,img_flag_x = 0,img_flag_x2 = 0,img_flag_x3 = 0,img_flag_x4 = 0,img_flag_x5 = 0,img_flag_x6 = 0,img_flag_x7 = 0,hour= 0 ;  

    GtkWidget * fixed_m_x;
    char str[100]="";
    int r,c,row,row1,col;

    void seats();
    void choose_seats();
    void seat_true();
    int seat_num(GtkButton *button,  int count);
    void end_learn();
    void return_back();
    void fast_seats();
    void seat_fast();

//-----------个人中心界面----------------------


    GtkWidget * label_z1;
    GtkWidget * entry_z1;
    GtkWidget * label_z2;
    GtkWidget * entry_z2;
    
    GtkWidget * window_z;
    GtkWidget * windowz_1;

    GtkWidget * fixed_z;
    GtkWidget * fixed_z1;

    GtkWidget * entry_z1;
    GtkWidget * entry_z11;
    GtkWidget * entry_z12;
    GtkWidget * label_z1;
    GtkWidget * label_z11;
    GtkWidget * label_z12;
    GtkWidget * label_z13;
    GtkWidget * label_z14;
    GtkWidget * label_z15;
    GtkWidget * label_zz1;
    GtkWidget * label_zz2;



//设置标签颜色  现成的三个以下函数
    int sungtk_color_get(const char *color_buf, GdkColor *color)
    {
        gdk_color_parse(color_buf, color);
        return 0;
    }
    int sungtk_widget_set_font_color(GtkWidget *widget, const char *color_buf, gboolean is_button)
    {
        if(widget == NULL && color_buf==NULL)
            return -1;
        
        GdkColor color;
        GtkWidget *labelChild = NULL;
        sungtk_color_get(color_buf, &color);
        if(is_button == TRUE){
            labelChild = gtk_bin_get_child(GTK_BIN(widget));//取出GtkButton里的label  
            gtk_widget_modify_fg(labelChild, GTK_STATE_NORMAL, &color);
            gtk_widget_modify_fg(labelChild, GTK_STATE_SELECTED, &color);
            gtk_widget_modify_fg(labelChild, GTK_STATE_PRELIGHT, &color);
        }else{
            gtk_widget_modify_fg(widget, GTK_STATE_NORMAL, &color);
        }
        return 0;
    }
    int sungtk_widget_set_font_size(GtkWidget *widget, int size, gboolean is_button)
    {
        GtkWidget *labelChild;  
        PangoFontDescription *font;  
        gint fontSize = size;  
        if(widget == NULL)
            return -1;
    
        font = pango_font_description_from_string("Sans");          //"Sans"字体名   
        pango_font_description_set_size(font, fontSize*PANGO_SCALE);//设置字体大小   
        
        if(is_button){
            labelChild = gtk_bin_get_child(GTK_BIN(widget));//取出GtkButton里的label  
        }else{
            labelChild = widget;
        }
        
        //设置label的字体，这样这个GtkButton上面显示的字体就变了
        gtk_widget_modify_font(GTK_WIDGET(labelChild), font);
        pango_font_description_free(font);

        return 0;
    }
    void load_image(GtkWidget *image, const char *file_path, const int w, const int h )
    {
        gtk_image_clear( GTK_IMAGE(image) ); // 清除图像
        GdkPixbuf *src_pixbuf = gdk_pixbuf_new_from_file(file_path, NULL); // 创建图片资源
        GdkPixbuf *dest_pixbuf=gdk_pixbuf_scale_simple(src_pixbuf,w,h,GDK_INTERP_BILINEAR); // 指定大小
        gtk_image_set_from_pixbuf(GTK_IMAGE(image), dest_pixbuf); // 图片控件重新设置一张图片(pixbuf)
        g_object_unref(src_pixbuf); // 释放资源
        g_object_unref(dest_pixbuf); // 释放资源
    }



//-----------登录界面----------------------
    //登录
    void login(GtkButton *button ,gpointer user_data)
    {
        const gchar * text = gtk_entry_get_text(GTK_ENTRY(entry));
        const gchar * text1 = gtk_entry_get_text(GTK_ENTRY(entry1));

        if (strcmp(text,"") == 0 || strcmp(text1,"")==0)
        {
                gtk_label_set_text(GTK_LABEL(label4),"请输入学号和密码");
        }
        else
        {
            char cmd[100]="";
            char ** table = NULL;
            int r,c;
            char * errmsg = NULL;
            sprintf(cmd,"select * from users where number ='%s'; ",text);
            sqlite3_get_table(db,cmd,&table,&r,&c,&errmsg);
            if (r == 0)
            {
                    gtk_label_set_text(GTK_LABEL(label4),"对不起，用户名不存在！！");
                    gtk_entry_set_text(GTK_ENTRY(entry),"");
                    gtk_entry_set_text(GTK_ENTRY(entry1),"");
            }
            else
            {
                sprintf(cmd,"select * from users where number ='%s'; ",text);
                sqlite3_get_table(db,cmd,&table,&r,&c,&errmsg);
                if (strcmp(table[4],text1)==0)//-------------where语句取密码
                {
                    //跳转页面：
                    // 隐藏当前显示的页面
                    gtk_widget_hide_all(window);
                        // 显示目的界面：
                    gtk_widget_show_all(window3);
                    gtk_entry_set_text(GTK_ENTRY(entry),"");
                    gtk_entry_set_text(GTK_ENTRY(entry1),"");
                      
                }
                else
                {
                    gtk_label_set_text(GTK_LABEL(label4),"对不起，用户名或密码错误！！");
                // gtk_entry_set_text(GTK_ENTRY(entry),"");
                    gtk_entry_set_text(GTK_ENTRY(entry1),"");
                }
            }
        }
    }
    //忘记密码
    void forget(GtkButton *button ,gpointer user_data)
    {
        gtk_label_set_text(GTK_LABEL(label4),"");
        gtk_widget_hide_all(window);
        gtk_widget_show_all(window1);

    }
    //立即注册
    void reg(GtkButton *button ,gpointer user_data)
    {
        gtk_label_set_text(GTK_LABEL(label4),"");
        gtk_widget_hide_all(window);
        gtk_widget_show_all(window2);

    }
//


//-----------忘记密码界面----------------------
    void back_n1(GtkButton *button ,gpointer user_data)
    {
        gtk_widget_hide_all(window1);
        gtk_widget_show_all(window);
    }
    void login_back1(GtkButton *button ,gpointer user_data)
    {

        const gchar * text_1 = gtk_entry_get_text(GTK_ENTRY(entry_1));
        const gchar * text_11 = gtk_entry_get_text(GTK_ENTRY(entry_11));
        const gchar * text_12 = gtk_entry_get_text(GTK_ENTRY(entry_12));

        if (strcmp(text_1,"") == 0 || strcmp(text_11,"")==0 || strcmp(text_12,"")==0)
        {
                gtk_label_set_text(GTK_LABEL(label_15),"请输入学号、新密码、确认密码");
        }
        else
        {

            char cmd[100]="";
            char ** table = NULL;
            int r,c;
            char * errmsg = NULL;
            if (strcmp(text_11,text_12)!=0)
            {
                gtk_label_set_text(GTK_LABEL(label_15),"两次密码不一致！");
            }
            else
            {
            sprintf(cmd,"update users set password = '%s' where number = '%s';" ,text_12,text_1);
            sqlite3_get_table(db,cmd,&table,&r,&c,&errmsg);
            // printf("%s\n",text_2 );
            
            //跳转页面：
            // 隐藏当前显示的页面
            gtk_widget_hide_all(window1);
                // 显示目的界面：
            gtk_widget_show_all(window);
            
            gtk_entry_set_text(GTK_ENTRY(entry_1),"");
            gtk_entry_set_text(GTK_ENTRY(entry_11),"");
            gtk_entry_set_text(GTK_ENTRY(entry_12),"");
            }
           
        }

    }

//



//-----------注册界面----------------------
    void back_n(GtkButton *button ,gpointer user_data)
    {
        gtk_widget_hide_all(window2);
        gtk_widget_show_all(window);
    }
    void login_back(GtkButton *button ,gpointer user_data)
    {

        const gchar * text_2 = gtk_entry_get_text(GTK_ENTRY(entry_2));
        const gchar * text_21 = gtk_entry_get_text(GTK_ENTRY(entry_21));
        const gchar * text_22 = gtk_entry_get_text(GTK_ENTRY(entry_22));

        if (strcmp(text_2,"") == 0 || strcmp(text_21,"")==0 || strcmp(text_22,"")==0)
        {
                gtk_label_set_text(GTK_LABEL(label_25),"请输入学号、密码、手机号");
        }
        else
        {

            char cmd[100]="";
            char ** table = NULL;
            int r,c;
            char * errmsg = NULL;
            sprintf(cmd,"insert into users values('%s','%s','%s');" ,text_2,text_21,text_22);
            sqlite3_get_table(db,cmd,&table,&r,&c,&errmsg);
            // printf("%s\n",text_2 );
            
            //跳转页面：
            // 隐藏当前显示的页面
            gtk_widget_hide_all(window2);
                // 显示目的界面：
            gtk_widget_show_all(window);
        
        }

    }
//

//-----------主页界面----------------------
    //个人中心
    void user(GtkButton *button ,gpointer user_data)
    {
        
        const gchar * text_2n = gtk_entry_get_text(GTK_ENTRY(entry_2));
        // const gchar * text_21n = gtk_entry_get_text(GTK_ENTRY(entry_21));
        const gchar * text_22n = gtk_entry_get_text(GTK_ENTRY(entry_22));

        label_zz1 = gtk_label_new("");
	    gtk_fixed_put(GTK_FIXED(fixed_z),label_zz1,500,200);
	    sungtk_widget_set_font_size(label_zz1,15,FALSE);
        gtk_label_set_text(GTK_LABEL(label_zz1),text_2n);

        label_zz2 = gtk_label_new("");
	    gtk_fixed_put(GTK_FIXED(fixed_z),label_zz2,500,300);
	    sungtk_widget_set_font_size(label_zz2,15,FALSE);
        gtk_label_set_text(GTK_LABEL(label_zz2),text_22n);



        

        gtk_widget_hide_all(window3);
        gtk_widget_show_all(window_z);


    }
    //图书借阅系统
    void book_system(GtkButton *button ,gpointer user_data)
    {
        gtk_widget_hide_all(window3);
        gtk_widget_show_all(window_y1);

    }

    //座位预约系统 header
    void seat_system(GtkButton *button ,gpointer user_data)
    {
        gtk_widget_hide_all(window3);
        gtk_widget_show_all(window_x);

    }
    void header(GtkButton *button ,gpointer user_data)
    {
        printf("嘿嘿\n");
    }
//


//-----------图书借阅界面----------------------

    void chaxun(GtkButton *button ,gpointer user_data)
    {
        gtk_widget_hide_all(window_y);
        gtk_widget_show_all(window1);
    }

    //跳转到根据id查询页面
    void juanzeng(GtkButton *button ,gpointer user_data)
    {
        gtk_widget_hide_all(window_y1);
        gtk_widget_show_all(window_y5);
    }
    void juanzengok(GtkButton *button ,gpointer user_data)
    {
        const gchar * id = gtk_entry_get_text(GTK_ENTRY(entry_y3));
        const gchar * name = gtk_entry_get_text(GTK_ENTRY(entry_y4));
        const gchar * writer = gtk_entry_get_text(GTK_ENTRY(entry_y5));
        if(strcmp(id,"") == 0 || strcmp(name,"") == 0 || strcmp(writer,"") == 0)
        {
            gtk_label_set_text(GTK_LABEL(label_y21),"请输入完整的信息！"); // 设置内容
        }
        else
        {
            char cmd1[100]="";
            char cmd2[100]="";
            char cmd3[100]="";
            int r,c;
            int r1,c1;
            char ** table = NULL;
            char * errmsg = NULL;
            sprintf(cmd1,"insert into library values('%s','%s','%s','未借阅'); ",id,name,writer);
            sprintf(cmd2,"select * from library where id ='%s'; ",id);
            sqlite3_get_table(db_y,cmd2,&table,&r,&c,&errmsg);
            sprintf(cmd3,"select * from library where name ='%s'; ",name);
            sqlite3_get_table(db_y,cmd3,&table,&r1,&c1,&errmsg);
            if(r == 0)
            {
                if (r1 == 0)
                {
                    sqlite3_exec(db_y,cmd1,NULL,NULL,&errmsg);
                    gtk_label_set_text(GTK_LABEL(label_y21),"捐赠成功！"); // 设置内容
                }
                else
                {
                    gtk_label_set_text(GTK_LABEL(label_y21),"已存在该书名！"); // 设置内容
                }	
            }
            else
            {
                gtk_label_set_text(GTK_LABEL(label_y21),"已存在该编号！"); // 设置内容
            }
                
        }
            
        
    }
    void chaxun1(GtkButton *button ,gpointer user_data)
    {
        gtk_widget_hide_all(window_y1);
        gtk_widget_show_all(window_y2);
    }
    //跳转到根据书名查询页面
    void chaxun2(GtkButton *button ,gpointer user_data)
    {
        gtk_widget_hide_all(window_y1);
        gtk_widget_show_all(window_y3);
    }

    //跳转到根据作者查询页面
    void chaxun3(GtkButton *button ,gpointer user_data)
    {
        gtk_widget_hide_all(window_y1);
        gtk_widget_show_all(window_y4);
    }
    //返回上一个页面
    void back_n2(GtkButton *button ,gpointer user_data)
    {
        gtk_widget_hide_all(window_y1);
        gtk_widget_show_all(window3);
    }
    void back2(GtkButton *button ,gpointer user_data)
    {
        gtk_widget_hide_all(window_y2);
        gtk_widget_show_all(window_y1);
        gtk_entry_set_text(GTK_ENTRY(entry_y),""); // 设置内容
        gtk_label_set_text(GTK_LABEL(label_y6),""); // 设置内容
        gtk_label_set_text(GTK_LABEL(label_y7),""); // 设置内容
        gtk_label_set_text(GTK_LABEL(label_y8),""); // 设置内容
        gtk_label_set_text(GTK_LABEL(label_y9),""); // 设置内容
    }
    void back3(GtkButton *button ,gpointer user_data)
    {
        gtk_widget_hide_all(window_y3);
        gtk_widget_show_all(window_y1);
        gtk_entry_set_text(GTK_ENTRY(entry_y1),""); // 设置内容
        gtk_label_set_text(GTK_LABEL(label_y10),""); // 设置内容
        gtk_label_set_text(GTK_LABEL(label_y11),""); // 设置内容
        gtk_label_set_text(GTK_LABEL(label_y12),""); // 设置内容
        gtk_label_set_text(GTK_LABEL(label_y13),""); // 设置内容
    }
    void back4(GtkButton *button ,gpointer user_data)
    {
        gtk_widget_hide_all(window_y4);
        gtk_widget_show_all(window_y1);
        gtk_entry_set_text(GTK_ENTRY(entry_y2),""); // 设置内容
        gtk_label_set_text(GTK_LABEL(label_y14),""); // 设置内容
        gtk_label_set_text(GTK_LABEL(label_y15),""); // 设置内容
        gtk_label_set_text(GTK_LABEL(label_y16),""); // 设置内容
        gtk_label_set_text(GTK_LABEL(label_y17),""); // 设置内容
    }
    void back5(GtkButton *button ,gpointer user_data)
    {
        gtk_widget_hide_all(window_y5);
        gtk_widget_show_all(window_y1);
        gtk_label_set_text(GTK_LABEL(label_y21),""); // 设置内容
        gtk_entry_set_text(GTK_ENTRY(entry_y3),""); // 设置内容
        gtk_entry_set_text(GTK_ENTRY(entry_y4),""); // 设置内容
        gtk_entry_set_text(GTK_ENTRY(entry_y5),""); // 设置内容
    }
    void back6(GtkButton *button ,gpointer user_data)
    {
        gtk_widget_hide_all(window_y6);
        gtk_widget_show_all(window_y1);
        gtk_label_set_text(GTK_LABEL(label_y26),""); // 设置内容
        gtk_label_set_text(GTK_LABEL(label_y27),""); // 设置内容
        gtk_label_set_text(GTK_LABEL(label_y28),""); // 设置内容
        gtk_label_set_text(GTK_LABEL(label_y29),""); // 设置内容
        gtk_label_set_text(GTK_LABEL(label_y30),""); // 设置内容
        gtk_label_set_text(GTK_LABEL(label_y31),""); // 设置内容
        gtk_label_set_text(GTK_LABEL(label_y32),""); // 设置内容
        gtk_label_set_text(GTK_LABEL(label_y33),""); // 设置内容
        
    }

    void backfromid(GtkButton *button ,gpointer user_data)
    {
        const gchar * id = gtk_entry_get_text(GTK_ENTRY(entry_y));
        const gchar *idd = gtk_label_get_label(GTK_LABEL(label_y6));
        const gchar *name = gtk_label_get_label(GTK_LABEL(label_y7));
        const gchar *writer = gtk_label_get_label(GTK_LABEL(label_y8));
        const gchar *state = gtk_label_get_label(GTK_LABEL(label_y9));
        char cmd1[100]="";
        char cmd2[100]="";
        int r,c;
        char ** table = NULL;
        char * errmsg = NULL;
        sprintf(cmd1,"update library set state = '未借阅' where id ='%s'; ",id);
        sqlite3_exec(db_y,cmd1,NULL,NULL,&errmsg);
        sprintf(cmd2,"select * from library where id ='%s'; ",id);
        sqlite3_get_table(db_y,cmd2,&table,&r,&c,&errmsg);
        idd = table[4];
        name = table[5];
        writer = table[6];
        state = table[7];
        gtk_label_set_text(GTK_LABEL(label_y6),idd); // 设置内容
        gtk_label_set_text(GTK_LABEL(label_y7),name); // 设置内容
        gtk_label_set_text(GTK_LABEL(label_y8),writer); // 设置内容
        gtk_label_set_text(GTK_LABEL(label_y9),state); // 设置内容
    }
    void backfromname(GtkButton *button ,gpointer user_data)
    {
        const gchar * name = gtk_entry_get_text(GTK_ENTRY(entry_y1));
        const gchar *idd = gtk_label_get_label(GTK_LABEL(label_y10));
        const gchar *name1 = gtk_label_get_label(GTK_LABEL(label_y11));
        const gchar *writer = gtk_label_get_label(GTK_LABEL(label_y12));
        const gchar *state = gtk_label_get_label(GTK_LABEL(label_y13));
        char cmd1[100]="";
        char cmd2[100]="";
        int r,c;
        char ** table = NULL;
        char * errmsg = NULL;
        sprintf(cmd1,"update library set state = '未借阅' where name ='%s'; ",name);
        sqlite3_exec(db_y,cmd1,NULL,NULL,&errmsg);
        sprintf(cmd2,"select * from library where name ='%s'; ",name);
        sqlite3_get_table(db_y,cmd2,&table,&r,&c,&errmsg);
        idd = table[4];
        name1 = table[5];
        writer = table[6];
        state = table[7];
        gtk_label_set_text(GTK_LABEL(label_y10),idd); // 设置内容
        gtk_label_set_text(GTK_LABEL(label_y11),name1); // 设置内容
        gtk_label_set_text(GTK_LABEL(label_y12),writer); // 设置内容
        gtk_label_set_text(GTK_LABEL(label_y13),state); // 设置内容
    }
    void backfromwriter(GtkButton *button ,gpointer user_data)
    {
        const gchar * writer = gtk_entry_get_text(GTK_ENTRY(entry_y2));
        const gchar *idd = gtk_label_get_label(GTK_LABEL(label_y14));
        const gchar *name = gtk_label_get_label(GTK_LABEL(label_y15));
        const gchar *writer1 = gtk_label_get_label(GTK_LABEL(label_y16));
        const gchar *state = gtk_label_get_label(GTK_LABEL(label_y17));
        char cmd1[100]="";
        char cmd2[100]="";
        int r,c;
        char ** table = NULL;
        char * errmsg = NULL;
        sprintf(cmd1,"update library set state = '未借阅' where writer ='%s'; ",writer);
        sqlite3_exec(db_y,cmd1,NULL,NULL,&errmsg);
        sprintf(cmd2,"select * from library where writer ='%s'; ",writer);
        sqlite3_get_table(db_y,cmd2,&table,&r,&c,&errmsg);
        idd = table[4];
        name = table[5];
        writer1 = table[6];
        state = table[7];
        gtk_label_set_text(GTK_LABEL(label_y14),idd); // 设置内容
        gtk_label_set_text(GTK_LABEL(label_y15),name); // 设置内容
        gtk_label_set_text(GTK_LABEL(label_y16),writer1); // 设置内容
        gtk_label_set_text(GTK_LABEL(label_y17),state); // 设置内容
    }
    void chaxunname(GtkButton *button ,gpointer user_data)
    {
        const gchar * name = gtk_entry_get_text(GTK_ENTRY(entry_y1));
        const gchar *idd = gtk_label_get_label(GTK_LABEL(label_y10));
        const gchar *name1 = gtk_label_get_label(GTK_LABEL(label_y11));
        const gchar *writer = gtk_label_get_label(GTK_LABEL(label_y12));
        const gchar *state = gtk_label_get_label(GTK_LABEL(label_y13));
        char cmd[100]="";
        char ** table = NULL;
        int r,c;
        char * errmsg = NULL;
        sprintf(cmd,"select * from library where name ='%s'; ",name);
        sqlite3_get_table(db_y,cmd,&table,&r,&c,&errmsg);
        idd = table[4];
        name1 = table[5];
        writer = table[6];
        state = table[7];
        if(r == 0)
        {
            gtk_label_set_text(GTK_LABEL(label_y10),"没有找到该书名的图书"); // 设置内容
            gtk_label_set_text(GTK_LABEL(label_y11),""); // 设置内容
            gtk_label_set_text(GTK_LABEL(label_y12),""); // 设置内容
            gtk_label_set_text(GTK_LABEL(label_y13),""); // 设置内容
        }
        else
        {
            gtk_label_set_text(GTK_LABEL(label_y10),idd); // 设置内容
            gtk_label_set_text(GTK_LABEL(label_y11),name1); // 设置内容
            gtk_label_set_text(GTK_LABEL(label_y12),writer); // 设置内容
            gtk_label_set_text(GTK_LABEL(label_y13),state); // 设置内容
        }
    }
    void chaxunid(GtkButton *button ,gpointer user_data)
    {
        const gchar * id = gtk_entry_get_text(GTK_ENTRY(entry_y));
        const gchar *idd = gtk_label_get_label(GTK_LABEL(label_y6));
        const gchar *name = gtk_label_get_label(GTK_LABEL(label_y7));
        const gchar *writer = gtk_label_get_label(GTK_LABEL(label_y8));
        const gchar *state = gtk_label_get_label(GTK_LABEL(label_y9));
        char cmd[100]="";
        char ** table = NULL;
        int r,c;
        char * errmsg = NULL;
        sprintf(cmd,"select * from library where id ='%s'; ",id);
        sqlite3_get_table(db_y,cmd,&table,&r,&c,&errmsg);
        idd = table[4];
        name = table[5];
        writer = table[6];
        state = table[7];
        if(r == 0)
        {
            gtk_label_set_text(GTK_LABEL(label_y6),"没有找到该编号的图书"); // 设置内容
            gtk_label_set_text(GTK_LABEL(label_y7),""); // 设置内容
            gtk_label_set_text(GTK_LABEL(label_y8),""); // 设置内容
            gtk_label_set_text(GTK_LABEL(label_y9),""); // 设置内容
        }
        else
        {
            gtk_label_set_text(GTK_LABEL(label_y6),idd); // 设置内容
            gtk_label_set_text(GTK_LABEL(label_y7),name); // 设置内容
            gtk_label_set_text(GTK_LABEL(label_y8),writer); // 设置内容
            gtk_label_set_text(GTK_LABEL(label_y9),state); // 设置内容
        }
    }
    void chaxunwriter(GtkButton *button ,gpointer user_data)
    {
        const gchar * writer = gtk_entry_get_text(GTK_ENTRY(entry_y2));
        const gchar *idd = gtk_label_get_label(GTK_LABEL(label_y14));
        const gchar *name = gtk_label_get_label(GTK_LABEL(label_y15));
        const gchar *writer1 = gtk_label_get_label(GTK_LABEL(label_y16));
        const gchar *state = gtk_label_get_label(GTK_LABEL(label_y17));
        char cmd[100]="";
        char ** table = NULL;
        int r,c;
        char * errmsg = NULL;
        sprintf(cmd,"select * from library where writer ='%s'; ",writer);
        sqlite3_get_table(db_y,cmd,&table,&r,&c,&errmsg);
        idd = table[4];
        name = table[5];
        writer1 = table[6];
        state = table[7];
        if(r == 0)
        {
            gtk_label_set_text(GTK_LABEL(label_y14),"没有找到该作者的图书"); // 设置内容
            gtk_label_set_text(GTK_LABEL(label_y15),""); // 设置内容
            gtk_label_set_text(GTK_LABEL(label_y16),""); // 设置内容
            gtk_label_set_text(GTK_LABEL(label_y17),""); // 设置内容
        }
        else
        {
            gtk_label_set_text(GTK_LABEL(label_y14),idd); // 设置内容
            gtk_label_set_text(GTK_LABEL(label_y15),name); // 设置内容
            gtk_label_set_text(GTK_LABEL(label_y16),writer1); // 设置内容
            gtk_label_set_text(GTK_LABEL(label_y17),state); // 设置内容
        }
    }
    void selectfromid(GtkButton *button ,gpointer user_data)
    {
        const gchar * id = gtk_entry_get_text(GTK_ENTRY(entry_y));
        const gchar *idd = gtk_label_get_label(GTK_LABEL(label_y6));
        const gchar *name = gtk_label_get_label(GTK_LABEL(label_y7));
        const gchar *writer = gtk_label_get_label(GTK_LABEL(label_y8));
        const gchar *state = gtk_label_get_label(GTK_LABEL(label_y9));
        char cmd1[100]="";
        char cmd2[100]="";
        int r,c;
        char ** table = NULL;
        char * errmsg = NULL;
        sprintf(cmd1,"update library set state = '已借阅' where id ='%s'; ",id);
        sqlite3_exec(db_y,cmd1,NULL,NULL,&errmsg);
        sprintf(cmd2,"select * from library where id ='%s'; ",id);
        sqlite3_get_table(db_y,cmd2,&table,&r,&c,&errmsg);
        idd = table[4];
        name = table[5];
        writer = table[6];
        state = table[7];
        gtk_label_set_text(GTK_LABEL(label_y6),idd); // 设置内容
        gtk_label_set_text(GTK_LABEL(label_y7),name); // 设置内容
        gtk_label_set_text(GTK_LABEL(label_y8),writer); // 设置内容
        gtk_label_set_text(GTK_LABEL(label_y9),state); // 设置内容
        
    }

    void selectfromname(GtkButton *button ,gpointer user_data)
    {
        const gchar * name = gtk_entry_get_text(GTK_ENTRY(entry_y1));
        const gchar *idd = gtk_label_get_label(GTK_LABEL(label_y10));
        const gchar *name1 = gtk_label_get_label(GTK_LABEL(label_y11));
        const gchar *writer = gtk_label_get_label(GTK_LABEL(label_y12));
        const gchar *state = gtk_label_get_label(GTK_LABEL(label_y13));
        char cmd1[100]="";
        char cmd2[100]="";
        int r,c;
        char ** table = NULL;
        char * errmsg = NULL;
        sprintf(cmd1,"update library set state = '已借阅' where name ='%s'; ",name);
        sqlite3_exec(db_y,cmd1,NULL,NULL,&errmsg);
        sprintf(cmd2,"select * from library where name ='%s'; ",name);
        sqlite3_get_table(db_y,cmd2,&table,&r,&c,&errmsg);
        idd = table[4];
        name1 = table[5];
        writer = table[6];
        state = table[7];
        gtk_label_set_text(GTK_LABEL(label_y10),idd); // 设置内容
        gtk_label_set_text(GTK_LABEL(label_y11),name1); // 设置内容
        gtk_label_set_text(GTK_LABEL(label_y12),writer); // 设置内容
        gtk_label_set_text(GTK_LABEL(label_y13),state); // 设置内容
    }
    void selectfromwriter(GtkButton *button ,gpointer user_data)
    {
        const gchar * writer = gtk_entry_get_text(GTK_ENTRY(entry_y2));
        const gchar *idd = gtk_label_get_label(GTK_LABEL(label_y14));
        const gchar *name = gtk_label_get_label(GTK_LABEL(label_y15));
        const gchar *writer1 = gtk_label_get_label(GTK_LABEL(label_y16));
        const gchar *state = gtk_label_get_label(GTK_LABEL(label_y17));
        char cmd1[100]="";
        char cmd2[100]="";
        int r,c;
        char ** table = NULL;
        char * errmsg = NULL;
        sprintf(cmd1,"update library set state = '已借阅' where writer ='%s'; ",writer);
        sqlite3_exec(db_y,cmd1,NULL,NULL,&errmsg);
        sprintf(cmd2,"select * from library where writer ='%s'; ",writer);
        sqlite3_get_table(db_y,cmd2,&table,&r,&c,&errmsg);
        idd = table[4];
        name = table[5];
        writer1 = table[6];
        state = table[7];
        gtk_label_set_text(GTK_LABEL(label_y14),idd); // 设置内容
        gtk_label_set_text(GTK_LABEL(label_y15),name); // 设置内容
        gtk_label_set_text(GTK_LABEL(label_y16),writer1); // 设置内容
        gtk_label_set_text(GTK_LABEL(label_y17),state); // 设置内容
    }


    void lishi(GtkButton *button ,gpointer user_data)
    {
        gtk_widget_hide_all(window_y1);
        gtk_widget_show_all(window_y6);
    }
    void chaxunlishi(GtkButton *button ,gpointer user_data)
    {
        const gchar *id3 = gtk_label_get_label(GTK_LABEL(label_y26));
        const gchar *name3 = gtk_label_get_label(GTK_LABEL(label_y27));
        const gchar *writer3 = gtk_label_get_label(GTK_LABEL(label_y28));
        const gchar *state3 = gtk_label_get_label(GTK_LABEL(label_y29));
        const gchar *id4 = gtk_label_get_label(GTK_LABEL(label_y30));
        const gchar *name4 = gtk_label_get_label(GTK_LABEL(label_y31));
        const gchar *writer4 = gtk_label_get_label(GTK_LABEL(label_y32));
        const gchar *state4 = gtk_label_get_label(GTK_LABEL(label_y33));
        char cmd4[100]="";
        int r,c;
        char ** table = NULL;
        char * errmsg = NULL;
        sprintf(cmd4,"select * from library where state = '已借阅';");
        sqlite3_get_table(db_y,cmd4,&table,&r,&c,&errmsg);
        if (r == 0)
        {
            gtk_label_set_text(GTK_LABEL(label_y26),"你当前没有正借阅图书"); // 设置内容
        }
        if(r == 2)
        {
            id3 = table[4];
            name3 = table[5];
            writer3 = table[6];
            state3 = table[7];	
            id4 = table[8];
            name4 = table[9];
            writer4 = table[10];
            state4 = table[11];
            gtk_label_set_text(GTK_LABEL(label_y26),id3); // 设置内容
            gtk_label_set_text(GTK_LABEL(label_y27),name3); // 设置内容
            gtk_label_set_text(GTK_LABEL(label_y28),writer3); // 设置内容
            gtk_label_set_text(GTK_LABEL(label_y29),state3); // 设置内容
            gtk_label_set_text(GTK_LABEL(label_y30),id4); // 设置内容
            gtk_label_set_text(GTK_LABEL(label_y31),name4); // 设置内容
            gtk_label_set_text(GTK_LABEL(label_y32),writer4); // 设置内容
            gtk_label_set_text(GTK_LABEL(label_y33),state4); // 设置内容
        }
        if(r == 1)
        {
            id3 = table[4];
            name3 = table[5];
            writer3 = table[6];
            state3 = table[7];	
            gtk_label_set_text(GTK_LABEL(label_y26),id3); // 设置内容
            gtk_label_set_text(GTK_LABEL(label_y27),name3); // 设置内容
            gtk_label_set_text(GTK_LABEL(label_y28),writer3); // 设置内容
            gtk_label_set_text(GTK_LABEL(label_y29),state3); // 设置内容
        }
        // else
        // {
        //     gtk_label_set_text(GTK_LABEL(label_y26),"ssxxxx"); // 设置内容
        // }
    }

//

//-----------个人中心界面----------------------
    void back_n4(GtkButton *button ,gpointer user_data)
    {
        gtk_widget_hide_all(window_z);
        gtk_widget_show_all(window3);
    }
    void chongzhi(GtkButton *button ,gpointer user_data)
    {
        gtk_widget_hide_all(window_z);
        gtk_widget_show_all(windowz_1);
    }
    void tuichu(GtkButton *button ,gpointer user_data)
    {
        gtk_label_set_text(GTK_LABEL(label4),"");
        gtk_widget_hide_all(window_z);
        gtk_widget_show_all(window);
    }
    void back_n5(GtkButton *button ,gpointer user_data)
    {
        gtk_widget_hide_all(windowz_1);
        gtk_widget_show_all(window_z);
    }
    void login_back5(GtkButton *button ,gpointer user_data)
    {
        // gtk_widget_hide_all(windowz_1);
        // gtk_widget_show_all(window_z);
        const gchar * text_z1 = gtk_entry_get_text(GTK_ENTRY(entry_z1));
        const gchar * text_z11 = gtk_entry_get_text(GTK_ENTRY(entry_z11));
        const gchar * text_z12 = gtk_entry_get_text(GTK_ENTRY(entry_z12));

        if (strcmp(text_z1,"") == 0 || strcmp(text_z11,"")==0 || strcmp(text_z12,"")==0)
        {
                gtk_label_set_text(GTK_LABEL(label_z15),"请输入旧密码、新密码、确认密码");
        }
        else
        {

            char cmd[100]="";
            char ** table = NULL;
            int r,c;
            char * errmsg = NULL;
            if (strcmp(text_z11,text_z12)!=0)
            {
                gtk_label_set_text(GTK_LABEL(label_z15),"两次密码不一致！");
            }
            else
            {
            sprintf(cmd,"update users set password = '%s' where password = '%s';" ,text_z12,text_z1);
            sqlite3_get_table(db,cmd,&table,&r,&c,&errmsg);
            // printf("%s\n",text_2 );
            
            //跳转页面：
            // 隐藏当前显示的页面
            gtk_widget_hide_all(windowz_1);
                // 显示目的界面：
            gtk_widget_show_all(window_z);
            
            gtk_entry_set_text(GTK_ENTRY(entry_z1),"");
            gtk_entry_set_text(GTK_ENTRY(entry_z11),"");
            gtk_entry_set_text(GTK_ENTRY(entry_z12),"");
            }
           
        }


        
    }

//


//-----------座位预约界面----------------------
    //定时器
    gboolean deal_time( gpointer* label ) 
    {
        static int min = 59, sec = 59;
        char buf[50] = "";
        if (sec > 0)
        {
            sec--;
        }
        else
        {
            sec = 60;
            if (min > 0)
            {
                min--;
            }
            else
            {
                min = 60;
                if (hour > 0)
                {
                    hour--;
                }
                else
                {
                    hour = 0; min = 0; sec = 0;
                }
            }

        }
        sprintf(buf, "剩余时间：%d:%d:%d", hour,min,sec);
        gtk_label_set_text(GTK_LABEL(label), buf);
        return TRUE;//尽量返回TRUE
    }
    void back_n3(GtkButton *button ,gpointer user_data)
    {
        // printf("heih");
        gtk_widget_hide_all(window_x);
        gtk_widget_show_all(window3);
    }
    int seat_num(GtkButton *button,  int count)	//选座
    {
        
        flag_num_x = count;
        char str[100]="";
        int row = count;
        if (row > 8)
        {
            row = row - 8;
        }
        if(row > 16)
        {
            row = row - 8;
        }
        col = (count-1)/8+1;
        row1 = row;
        sprintf(str,"当前座位为：第%d排 第%d列",col,row);
        gtk_label_set_text(GTK_LABEL(label_x10),str);
    }

    void end_learn()	//结束学习
    {
        num_x = 0;
        g_source_remove(timer_x);
        gtk_label_set_text(GTK_LABEL(label_x9),"暂无选座");
        gtk_label_set_text(GTK_LABEL(label_time_x),"");
        gtk_container_add(GTK_CONTAINER(window_x), label_time_x);
        img_flag_x = 0 ; img_flag_x2 = 0; img_flag_x3 = 0;img_flag_x4 = 0;img_flag_x5 = 0;img_flag_x6 = 0;img_flag_x7 = 0;
    }
    void return_back()	//界面切换
    {
        gtk_widget_hide_all(window_x1);
        gtk_widget_hide_all(window_x2);
        g_source_remove(timer_x);
        choose_seats();
        gtk_widget_show_all(window_x);
    }
    void return_back2()	//界面切换
    {
        gtk_widget_hide_all(window_x2);  
    }
    //------------------------------------------------------------------------------写入
    void seat_true()	//座位确定
    {
        
        num_x = flag_num_x;
        if(col==1 && row1 == 1)
        {
            img_flag_x = 1;
            load_image(img_btn_x10,"imgs/使用中.png",30,30);
        }
        if(col==1 && row1 == 2)
        {
            img_flag_x2= 1;
            load_image(img_btn_x1,"imgs/使用中.png",30,30);
        }
        if(col==1 && row1 == 3)
        {
            img_flag_x3= 1;
            load_image(img_btn_x2,"imgs/使用中.png",30,30);
        }
        if(col==1 && row1 == 4)
        {
            img_flag_x4= 1;
            load_image(img_btn_x3,"imgs/使用中.png",30,30);
        }
        if(col==1 && row1 == 6)
        {
            img_flag_x5= 1;
            load_image(img_btn_x4,"imgs/使用中.png",30,30);
        }
        if(col==1 && row1 == 7)
        {
            img_flag_x6= 1;
            load_image(img_btn_x5,"imgs/使用中.png",30,30);
        }
        if(col==2 && row1 ==1)
        {
            img_flag_x7= 1;
            load_image(img_btn_x6,"imgs/使用中.png",30,30);
        }

        const gchar * time_x = gtk_entry_get_text(GTK_ENTRY(entry_x1));
        hour = atoi(time_x)-1;
    }

    void seat_fast()	//快速选座
    {
        
        int seat_NNN[7]={1,2,3,4,6,7,9};
        char i;
        char str[100]="";
        i=rand()%6;
        num_x = seat_NNN[i];
        int row = num_x;
        if (row > 8)
        {
            row = row - 8;
        }
        if(row > 16)
        {
            row = row - 8;
        }
        col = (num_x-1)/8+1;
        row1 = row;
        sprintf(str,"当前座位为：第%d排 第%d列",col,row);
        gtk_label_set_text(GTK_LABEL(label_x9),str);


        const gchar * time_x = gtk_entry_get_text(GTK_ENTRY(entry_x1));
        hour = atoi(time_x)-1;
    }


    void choose_seats()
    {
        
        
        window_x = gtk_window_new(GTK_WINDOW_TOPLEVEL);  
        gtk_widget_set_size_request(window_x,1080,600);
        g_signal_connect(window_x,"destroy",G_CALLBACK(gtk_main_quit),NULL);
        fixed_m_x = gtk_fixed_new();
        gtk_container_add(GTK_CONTAINER(window_x),fixed_m_x);

        GtkWidget * image_x1 = gtk_image_new_from_pixbuf(NULL);
        load_image(image_x1,"imgs/background.jpg",1080,600); //背景图片
        gtk_fixed_put(GTK_FIXED(fixed_m_x),image_x1,0,0);

        //label
        GtkWidget * label_x1;GtkWidget * label_x2;

        label_x1=gtk_label_new("选座学习");
        gtk_fixed_put(GTK_FIXED(fixed_m_x),label_x1,500,0);
        sungtk_widget_set_font_size(label_x1,20,FALSE);
        sungtk_widget_set_font_color(label_x1,"black",FALSE);

        label_x1=gtk_label_new("正常选座");
        gtk_fixed_put(GTK_FIXED(fixed_m_x),label_x1,240,200);
        sungtk_widget_set_font_size(label_x1,20,FALSE);
        sungtk_widget_set_font_color(label_x1,"black",FALSE);

        label_x1=gtk_label_new("快速选座");
        gtk_fixed_put(GTK_FIXED(fixed_m_x),label_x1,440,200);
        sungtk_widget_set_font_size(label_x1,20,FALSE);
        sungtk_widget_set_font_color(label_x1,"black",FALSE);

        // label1=gtk_label_new("学习记录");
        // gtk_fixed_put(GTK_FIXED(fixed_m),label1,600,200);
        // sungtk_widget_set_font_size(label1,20,FALSE);
        // sungtk_widget_set_font_color(label1,"black",FALSE);

        label_x1=gtk_label_new("规则说明");
        gtk_fixed_put(GTK_FIXED(fixed_m_x),label_x1,640,200);
        sungtk_widget_set_font_size(label_x1,20,FALSE);
        sungtk_widget_set_font_color(label_x1,"black",FALSE);

        label_x2=gtk_label_new("当前选座");
        gtk_fixed_put(GTK_FIXED(fixed_m_x),label_x2,200,320);
        sungtk_widget_set_font_size(label_x2,20,FALSE);
        sungtk_widget_set_font_color(label_x2,"#00ccff",FALSE);

        //按钮加图片
        GtkWidget * button_x0 = gtk_button_new();	//返回主页面
        GtkWidget * img_btn_x0 = gtk_image_new_from_pixbuf(NULL);
        load_image(img_btn_x0,"imgs/返回.png",20,20);
        gtk_button_set_image(GTK_BUTTON(button_x0),img_btn_x0);
        gtk_fixed_put(GTK_FIXED(fixed_m_x),button_x0,5,5);
        gtk_button_set_relief(GTK_BUTTON(button_x0), GTK_RELIEF_NONE);//把按钮设置为透明
        g_signal_connect(button_x0,"pressed",G_CALLBACK(back_n3),NULL);

        GtkWidget * button_x1 = gtk_button_new();	//预约选座
        GtkWidget * img_btn_x1 = gtk_image_new_from_pixbuf(NULL);
        load_image(img_btn_x1,"imgs/座位蓝.png",60,60);
        gtk_button_set_image(GTK_BUTTON(button_x1),img_btn_x1);
        gtk_fixed_put(GTK_FIXED(fixed_m_x),button_x1,255,125);
        gtk_button_set_relief(GTK_BUTTON(button_x1), GTK_RELIEF_NONE);
        g_signal_connect(button_x1,"pressed",G_CALLBACK(seats),NULL);

        GtkWidget * button_x2 = gtk_button_new();	//快速选座
        GtkWidget * img_btn_x2 = gtk_image_new_from_pixbuf(NULL);
        load_image(img_btn_x2,"imgs/座位绿.png",60,60);
        gtk_button_set_image(GTK_BUTTON(button_x2),img_btn_x2);
        gtk_fixed_put(GTK_FIXED(fixed_m_x),button_x2,455,125);
        gtk_button_set_relief(GTK_BUTTON(button_x2), GTK_RELIEF_NONE);
        g_signal_connect(button_x2,"pressed",G_CALLBACK(fast_seats),NULL);

    

        GtkWidget * button_x4 = gtk_button_new();	//规则说明
        GtkWidget * img_btn_x4 = gtk_image_new_from_pixbuf(NULL);
        load_image(img_btn_x4,"imgs/文件红.png",60,60);
        gtk_button_set_image(GTK_BUTTON(button_x4),img_btn_x4);
        gtk_fixed_put(GTK_FIXED(fixed_m_x),button_x4,655,125);
        gtk_button_set_relief(GTK_BUTTON(button_x4), GTK_RELIEF_NONE);



        //-----------------------------------------------------------------------------分割线
        image_x1 = gtk_image_new_from_pixbuf(NULL);
        load_image(image_x1,"imgs/分割.png",1000,10); //分割
        gtk_fixed_put(GTK_FIXED(fixed_m_x),image_x1,50,300);

        // -----------------------------------------------------------------------------当前预约
            if (num_x !=0 )											//存在-显示
            {
                sprintf(str,"当前座位为：第%d排 第%d列",col,row1);
                gtk_label_set_text(GTK_LABEL(label_x9),str);
                label_x9=gtk_label_new(str);
                gtk_fixed_put(GTK_FIXED(fixed_m_x),label_x9,200,400);
                sungtk_widget_set_font_size(label_x9,20,FALSE);
                sungtk_widget_set_font_color(label_x9,"black",FALSE);
                //定时器
                label_time_x=gtk_label_new("");
                gtk_fixed_put(GTK_FIXED(fixed_m_x),label_time_x,400,320);
                gtk_container_add(GTK_CONTAINER(window_x), label_time_x);
                sungtk_widget_set_font_size(label_time_x,20,FALSE);
                timer_x = g_timeout_add(1000, (GSourceFunc)deal_time, (gpointer)label_time_x);
            }
            else												//不存在
            {
                label_x9=gtk_label_new("暂无记录");
                gtk_fixed_put(GTK_FIXED(fixed_m_x),label_x9,200,400);
                sungtk_widget_set_font_size(label_x9,20,FALSE);
                sungtk_widget_set_font_color(label_x9,"black",FALSE);
            }
        // -----------------------------------------------------------------------------结束当前学习
        GtkWidget * button_x19=gtk_button_new_with_label("我不卷了"); //我不卷了
        gtk_widget_set_size_request(button_x19,120,80);
        gtk_fixed_put(GTK_FIXED(fixed_m_x),button_x19,600,480);
        gtk_button_set_relief(GTK_BUTTON(button_x19),GTK_RELIEF_NONE);
        sungtk_widget_set_font_size(button_x19,15,TRUE);
        sungtk_widget_set_font_color(button_x19,"black",TRUE);
        g_signal_connect(button_x19,"pressed",G_CALLBACK(end_learn),NULL);
        // gtk_widget_show_all(window_x);

    }
    void seats()
    {

        gtk_widget_hide_all(window_x);

        window_x1 = gtk_window_new(GTK_WINDOW_TOPLEVEL);
        gtk_widget_set_size_request(window_x1,1080,600);
        g_signal_connect(window_x1,"destroy",G_CALLBACK(gtk_main_quit),NULL);
        GtkWidget * fixed_x = gtk_fixed_new();
        gtk_container_add(GTK_CONTAINER(window_x1),fixed_x);

        GtkWidget * image_x1 = gtk_image_new_from_pixbuf(NULL);
        load_image(image_x1,"imgs/background.jpg",1080,600); //背景图片
        gtk_fixed_put(GTK_FIXED(fixed_x),image_x1,0,0);

        //-------------------------------------------图例说明
        GtkWidget * label_x1=gtk_label_new("图例说明");
        gtk_fixed_put(GTK_FIXED(fixed_x),label_x1,100,50);
        sungtk_widget_set_font_size(label_x1,10,FALSE);
        sungtk_widget_set_font_color(label_x1,"black",FALSE);

        label_x1=gtk_label_new("空闲"); 		//空闲
        gtk_fixed_put(GTK_FIXED(fixed_x),label_x1,220,52);
        sungtk_widget_set_font_size(label_x1,7,FALSE);
        sungtk_widget_set_font_color(label_x1,"black",FALSE);

        GtkWidget * image_x2 = gtk_image_new_from_pixbuf(NULL);
        load_image(image_x2,"imgs/空闲.png",35,35);
        gtk_fixed_put(GTK_FIXED(fixed_x),image_x2,180,40);

        label_x1=gtk_label_new("imgs/被预约"); 		//被预约
        gtk_fixed_put(GTK_FIXED(fixed_x),label_x1,320,52);
        sungtk_widget_set_font_size(label_x1,7,FALSE);
        sungtk_widget_set_font_color(label_x1,"black",FALSE);

        image_x1 = gtk_image_new_from_pixbuf(NULL);
        load_image(image_x1,"被预约.png",35,35);
        gtk_fixed_put(GTK_FIXED(fixed_x),image_x1,280,40);

        label_x1=gtk_label_new("使用中"); 		//使用中
        gtk_fixed_put(GTK_FIXED(fixed_x),label_x1,420,52);
        sungtk_widget_set_font_size(label_x1,7,FALSE);
        sungtk_widget_set_font_color(label_x1,"black",FALSE);

        image_x1 = gtk_image_new_from_pixbuf(NULL);
        load_image(image_x1,"imgs/使用中.png",35,35);
        gtk_fixed_put(GTK_FIXED(fixed_x),image_x1,380,40);

        label_x1=gtk_label_new("imgs/暂离开"); 		//暂离开
        gtk_fixed_put(GTK_FIXED(fixed_x),label_x1,520,52);
        sungtk_widget_set_font_size(label_x1,7,FALSE);
        sungtk_widget_set_font_color(label_x1,"black",FALSE);

        image_x1 = gtk_image_new_from_pixbuf(NULL);
        load_image(image_x1,"imgs/暂离开.png",35,35);
        gtk_fixed_put(GTK_FIXED(fixed_x),image_x1,480,40);

        label_x1=gtk_label_new("不可用"); 		//不可用
        gtk_fixed_put(GTK_FIXED(fixed_x),label_x1,620,52);
        sungtk_widget_set_font_size(label_x1,7,FALSE);
        sungtk_widget_set_font_color(label_x1,"black",FALSE);

        image_x1 = gtk_image_new_from_pixbuf(NULL);
        load_image(image_x1,"imgs/不可用.png",35,35);
        gtk_fixed_put(GTK_FIXED(fixed_x),image_x1,580,40);

        //座位布局
        //---------------------------------------------------------------------第一排
        button_x1 = gtk_button_new();
        img_btn_x10 = gtk_image_new_from_pixbuf(NULL);
        if (img_flag_x == 1)
        {
            load_image(img_btn_x10,"imgs/使用中.png",30,30);
        }
        else
        {
            load_image(img_btn_x10,"imgs/空闲.png",30,30);
        }

        gtk_button_set_image(GTK_BUTTON(button_x1),img_btn_x10);
        gtk_fixed_put(GTK_FIXED(fixed_x),button_x1,100,100);
        gtk_button_set_relief(GTK_BUTTON(button_x1), GTK_RELIEF_NONE);
        g_signal_connect(button_x1,"pressed",G_CALLBACK(seat_num),(gpointer)count_x1);
        
        GtkWidget * button_x = gtk_button_new();
        img_btn_x1 = gtk_image_new_from_pixbuf(NULL);
        if (img_flag_x2 == 1)
        {
            load_image(img_btn_x1,"imgs/使用中.png",30,30);
        }
        else
        {
            load_image(img_btn_x1,"imgs/空闲.png",30,30);
        }
        gtk_button_set_image(GTK_BUTTON(button_x),img_btn_x1);
        gtk_fixed_put(GTK_FIXED(fixed_x),button_x,150,100);
        gtk_button_set_relief(GTK_BUTTON(button_x), GTK_RELIEF_NONE);
        g_signal_connect(button_x,"pressed",G_CALLBACK(seat_num),(gpointer)count_x2);

        button_x = gtk_button_new();
        img_btn_x2 = gtk_image_new_from_pixbuf(NULL);
        if (img_flag_x3 == 1)
        {
            load_image(img_btn_x2,"使用中.png",30,30);
        }
        else
        {
            load_image(img_btn_x2,"imgs/空闲.png",30,30);
        }
        gtk_button_set_image(GTK_BUTTON(button_x),img_btn_x2);
        gtk_fixed_put(GTK_FIXED(fixed_x),button_x,200,100);
        gtk_button_set_relief(GTK_BUTTON(button_x), GTK_RELIEF_NONE);
        g_signal_connect(button_x,"pressed",G_CALLBACK(seat_num),(gpointer)count_x3);

        button_x = gtk_button_new();
        img_btn_x3 = gtk_image_new_from_pixbuf(NULL);
        if (img_flag_x4 == 1)
        {
            load_image(img_btn_x3,"imgs/使用中.png",30,30);
        }
        else
        {
            load_image(img_btn_x3,"imgs/空闲.png",30,30);
        }
        gtk_button_set_image(GTK_BUTTON(button_x),img_btn_x3);
        gtk_fixed_put(GTK_FIXED(fixed_x),button_x,250,100);
        gtk_button_set_relief(GTK_BUTTON(button_x), GTK_RELIEF_NONE);
        g_signal_connect(button_x,"pressed",G_CALLBACK(seat_num),(gpointer)count_x4);

        button_x = gtk_button_new();
        GtkWidget * img_btn_x = gtk_image_new_from_pixbuf(NULL);
        load_image(img_btn_x,"imgs/暂离开.png",30,30);
        gtk_button_set_image(GTK_BUTTON(button_x),img_btn_x);
        gtk_fixed_put(GTK_FIXED(fixed_x),button_x,300,100);
        gtk_button_set_relief(GTK_BUTTON(button_x), GTK_RELIEF_NONE);
        g_signal_connect(button_x,"pressed",G_CALLBACK(seat_num),(gpointer)count_x5);

        button_x = gtk_button_new();
        img_btn_x4 = gtk_image_new_from_pixbuf(NULL);
        if (img_flag_x5 == 1)
        {
            load_image(img_btn_x4,"imgs/使用中.png",30,30);
        }
        else
        {
            load_image(img_btn_x4,"imgs/空闲.png",30,30);
        }
        gtk_button_set_image(GTK_BUTTON(button_x),img_btn_x4);
        gtk_fixed_put(GTK_FIXED(fixed_x),button_x,350,100);
        gtk_button_set_relief(GTK_BUTTON(button_x), GTK_RELIEF_NONE);
        g_signal_connect(button_x,"pressed",G_CALLBACK(seat_num),(gpointer)count_x6);

        button_x = gtk_button_new();
        img_btn_x5 = gtk_image_new_from_pixbuf(NULL);
        if (img_flag_x6 == 1)
        {
            load_image(img_btn_x5,"imgs/使用中.png",30,30);
        }
        else
        {
            load_image(img_btn_x5,"imgs/空闲.png",30,30);
        }
        gtk_button_set_image(GTK_BUTTON(button_x),img_btn_x5);
        gtk_fixed_put(GTK_FIXED(fixed_x),button_x,400,100);
        gtk_button_set_relief(GTK_BUTTON(button_x), GTK_RELIEF_NONE);
        g_signal_connect(button_x,"pressed",G_CALLBACK(seat_num),(gpointer)count_x7);

        button_x = gtk_button_new();
        img_btn_x = gtk_image_new_from_pixbuf(NULL);
        load_image(img_btn_x,"imgs/不可用.png",30,30);
        gtk_button_set_image(GTK_BUTTON(button_x),img_btn_x);
        gtk_fixed_put(GTK_FIXED(fixed_x),button_x,450,100);
        gtk_button_set_relief(GTK_BUTTON(button_x), GTK_RELIEF_NONE);
        g_signal_connect(button_x,"pressed",G_CALLBACK(seat_num),(gpointer)count_x8);

        //------------------------------------------------------------------------------第二排
        button_x = gtk_button_new();
        img_btn_x6 = gtk_image_new_from_pixbuf(NULL);
        if (img_flag_x7 == 1)
        {
            load_image(img_btn_x6,"imgs/使用中.png",30,30);
        }
        else
        {
            load_image(img_btn_x6,"imgs/空闲.png",30,30);
        }
        gtk_button_set_image(GTK_BUTTON(button_x),img_btn_x6);
        gtk_fixed_put(GTK_FIXED(fixed_x),button_x,100,150);
        gtk_button_set_relief(GTK_BUTTON(button_x), GTK_RELIEF_NONE);
        g_signal_connect(button_x,"pressed",G_CALLBACK(seat_num),(gpointer)count_x9);

        button_x = gtk_button_new();
        img_btn_x = gtk_image_new_from_pixbuf(NULL);
        load_image(img_btn_x,"imgs/使用中.png",30,30);
        gtk_button_set_image(GTK_BUTTON(button_x),img_btn_x);
        gtk_fixed_put(GTK_FIXED(fixed_x),button_x,150,150);
        gtk_button_set_relief(GTK_BUTTON(button_x), GTK_RELIEF_NONE);
        g_signal_connect(button_x,"pressed",G_CALLBACK(seat_num),(gpointer)count_x10);

        button_x = gtk_button_new();
        img_btn_x = gtk_image_new_from_pixbuf(NULL);
        load_image(img_btn_x,"imgs/暂离开.png",30,30);
        gtk_button_set_image(GTK_BUTTON(button_x),img_btn_x);
        gtk_fixed_put(GTK_FIXED(fixed_x),button_x,200,150);
        gtk_button_set_relief(GTK_BUTTON(button_x), GTK_RELIEF_NONE);
        g_signal_connect(button_x,"pressed",G_CALLBACK(seat_num),(gpointer)count_x11);

        button_x = gtk_button_new();
        img_btn_x = gtk_image_new_from_pixbuf(NULL);
        load_image(img_btn_x,"imgs/被预约.png",30,30);
        gtk_button_set_image(GTK_BUTTON(button_x),img_btn_x);
        gtk_fixed_put(GTK_FIXED(fixed_x),button_x,250,150);
        gtk_button_set_relief(GTK_BUTTON(button_x), GTK_RELIEF_NONE);
        g_signal_connect(button_x,"pressed",G_CALLBACK(seat_num),(gpointer)count_x12);

        button_x = gtk_button_new();
        img_btn_x = gtk_image_new_from_pixbuf(NULL);
        load_image(img_btn_x,"imgs/使用中.png",30,30);
        gtk_button_set_image(GTK_BUTTON(button_x),img_btn_x);
        gtk_fixed_put(GTK_FIXED(fixed_x),button_x,300,150);
        gtk_button_set_relief(GTK_BUTTON(button_x), GTK_RELIEF_NONE);
        g_signal_connect(button_x,"pressed",G_CALLBACK(seat_num),(gpointer)count_x13);

        button_x = gtk_button_new();
        img_btn_x = gtk_image_new_from_pixbuf(NULL);
        load_image(img_btn_x,"imgs/被预约.png",30,30);
        gtk_button_set_image(GTK_BUTTON(button_x),img_btn_x);
        gtk_fixed_put(GTK_FIXED(fixed_x),button_x,350,150);
        gtk_button_set_relief(GTK_BUTTON(button_x), GTK_RELIEF_NONE);
        g_signal_connect(button_x,"pressed",G_CALLBACK(seat_num),(gpointer)count_x14);

        button_x = gtk_button_new();
        img_btn_x = gtk_image_new_from_pixbuf(NULL);
        load_image(img_btn_x,"imgs/使用中.png",30,30);
        gtk_button_set_image(GTK_BUTTON(button_x),img_btn_x);
        gtk_fixed_put(GTK_FIXED(fixed_x),button_x,400,150);
        gtk_button_set_relief(GTK_BUTTON(button_x), GTK_RELIEF_NONE);
        g_signal_connect(button_x,"pressed",G_CALLBACK(seat_num),(gpointer)count_x15);

        button_x = gtk_button_new();
        img_btn_x = gtk_image_new_from_pixbuf(NULL);
        load_image(img_btn_x,"imgs/使用中.png",30,30);
        gtk_button_set_image(GTK_BUTTON(button_x),img_btn_x);
        gtk_fixed_put(GTK_FIXED(fixed_x),button_x,450,150);
        gtk_button_set_relief(GTK_BUTTON(button_x), GTK_RELIEF_NONE);
        g_signal_connect(button_x,"pressed",G_CALLBACK(seat_num),(gpointer)count_x16);


        //------------------------------------------------------------------------------返回
        GtkWidget * button_x0 = gtk_button_new();	//返回主页面
        GtkWidget * img_btn_x0 = gtk_image_new_from_pixbuf(NULL);
        load_image(img_btn_x0,"imgs/返回.png",20,20);
        gtk_button_set_image(GTK_BUTTON(button_x0),img_btn_x0);
        gtk_fixed_put(GTK_FIXED(fixed_x),button_x0,5,5);
        gtk_button_set_relief(GTK_BUTTON(button_x0), GTK_RELIEF_NONE);//把按钮设置为透明
        g_signal_connect(button_x0,"pressed",G_CALLBACK(return_back),NULL);

        //------------------------------------------------------------------------------时间
        GtkWidget * label_x3=gtk_label_new("时间(小时)");
        gtk_fixed_put(GTK_FIXED(fixed_x),label_x3,220,320);
        sungtk_widget_set_font_size(label_x3,20,FALSE);
        sungtk_widget_set_font_color(label_x3,"black",FALSE);

        entry_x1 =gtk_entry_new();
        gtk_fixed_put(GTK_FIXED(fixed_x),entry_x1,200,370);
        //------------------------------------------------------------------------------提示按钮
        label_x10=gtk_label_new("");
        gtk_fixed_put(GTK_FIXED(fixed_x),label_x10,400,350);
        sungtk_widget_set_font_size(label_x10,15,FALSE);
        sungtk_widget_set_font_color(label_x10,"black",FALSE);
        //------------------------------------------------------------------------------选座确定按钮
        button_x20=gtk_button_new_with_label("确定");
        gtk_widget_set_size_request(button_x20,120,80);
        gtk_fixed_put(GTK_FIXED(fixed_x),button_x20,400,480);
        gtk_button_set_relief(GTK_BUTTON(button_x20),GTK_RELIEF_NONE);
        sungtk_widget_set_font_size(button_x20,25,TRUE);
        sungtk_widget_set_font_color(button_x20,"black",TRUE);
        g_signal_connect(button_x20,"pressed",G_CALLBACK(seat_true),NULL);


        gtk_widget_show_all(window_x1);
    }
    void fast_seats()
    {
        char str[100]="";
        static int min = 59, sec = 59;
        window_x2 = gtk_window_new(GTK_WINDOW_TOPLEVEL);
        gtk_window_set_position(GTK_WINDOW(window_x2), GTK_WIN_POS_MOUSE);
        gtk_widget_set_size_request(window_x2,600,400);
        GtkWidget * fixed_x = gtk_fixed_new();
        gtk_container_add(GTK_CONTAINER(window_x2),fixed_x);

        GtkWidget * image_x1 = gtk_image_new_from_pixbuf(NULL);
        load_image(image_x1,"imgs/background.jpg",600,400); //背景图片
        gtk_fixed_put(GTK_FIXED(fixed_x),image_x1,0,0);

        //------------------------------------------------------------------------------头标签
        GtkWidget * label_x1=gtk_label_new("快速选座弹窗");
        gtk_fixed_put(GTK_FIXED(fixed_x),label_x1,280,10);
        sungtk_widget_set_font_size(label_x1,10,FALSE);
        sungtk_widget_set_font_color(label_x1,"black",FALSE);
        //------------------------------------------------------------------------------头标签
        label_x1=gtk_label_new("当前剩余座位数：");
        gtk_fixed_put(GTK_FIXED(fixed_x),label_x1,140,150);
        sungtk_widget_set_font_size(label_x1,15,FALSE);
        sungtk_widget_set_font_color(label_x1,"black",FALSE);

        label_x1=gtk_label_new("7");
        gtk_fixed_put(GTK_FIXED(fixed_x),label_x1,300,150);
        sungtk_widget_set_font_size(label_x1,15,FALSE);
        sungtk_widget_set_font_color(label_x1,"blue",FALSE);
        // //------------------------------------------------------------------------------时间标签
        GtkWidget * label_x3=gtk_label_new("时间(小时)");
        gtk_fixed_put(GTK_FIXED(fixed_x),label_x3,100,240);
        sungtk_widget_set_font_size(label_x3,15,FALSE);
        sungtk_widget_set_font_color(label_x3,"black",FALSE);

        entry_x1 =gtk_entry_new();
        gtk_fixed_put(GTK_FIXED(fixed_x),entry_x1,100,280);

        button_x21=gtk_button_new_with_label("快速选座");
        gtk_widget_set_size_request(button_x21,100,70);
        gtk_fixed_put(GTK_FIXED(fixed_x),button_x21,280,250);
        gtk_button_set_relief(GTK_BUTTON(button_x21),GTK_RELIEF_NONE);
        sungtk_widget_set_font_size(button_x21,15,TRUE);
        sungtk_widget_set_font_color(button_x21,"black",TRUE);
        g_signal_connect(button_x21,"pressed",G_CALLBACK(seat_fast),NULL);

        GtkWidget * button_x0 = gtk_button_new();	//返回主页面
        GtkWidget * img_btn_x0 = gtk_image_new_from_pixbuf(NULL);
        load_image(img_btn_x0,"imgs/返回.png",20,20);
        gtk_button_set_image(GTK_BUTTON(button_x0),img_btn_x0);
        gtk_fixed_put(GTK_FIXED(fixed_x),button_x0,5,5);
        gtk_button_set_relief(GTK_BUTTON(button_x0), GTK_RELIEF_NONE);//把按钮设置为透明
        g_signal_connect(button_x0,"pressed",G_CALLBACK(return_back2),NULL);

        //------------------------------------------------------------------------------时间
        g_source_remove(timer_x);
        timer_x = g_timeout_add(1000, (GSourceFunc)deal_time, (gpointer)label_time_x);  

        label_time_x=gtk_label_new("");
        gtk_fixed_put(GTK_FIXED(fixed_m_x),label_time_x,400,320);
        gtk_container_add(GTK_CONTAINER(window_x), label_time_x);
        sungtk_widget_set_font_size(label_time_x,20,FALSE);

        const gchar * time_x = gtk_entry_get_text(GTK_ENTRY(entry_x1));
        hour = atoi(time_x)-1;

        sprintf(str, "剩余时间：%d:%d:%d", hour,min,sec);
        gtk_label_set_text(GTK_LABEL(label_time_x), str);
    // ----------------------------------------
        gtk_widget_show_all(window_x2);
    }
// 

void* read_card(void *arg)
{
    int len,i;char type;
    unsigned char id[18] = {0};
    //捕获信号

    uart_rfid_init(UART_DEV);
    while(1)
    {
        char rfid_buf[128]="";
        if(len = get_rfid_card_id(id,&type)){
            printf("%c类卡卡号:",type);
            for(i=0;i<len;i++)
                sprintf(rfid_buf+strlen(rfid_buf),"%02x:", id[i]);          
            rfid_buf[strlen(rfid_buf)-1]=0;
        }

        if(strlen(rfid_buf) != 0)
        {
            printf("rfid_buf=%s\n", rfid_buf);
            //进入数据库查询
            //调用非回调函数  
            char **result=NULL;  
            char *errmsg=NULL;
            int nRow = 0;//存放行数  
            int nCol = 0;//存放列数
            char cmd[128]="";


            sprintf(cmd,"select * from marvel where id=\'%s\';", rfid_buf);  
            sqlite3_get_table(db,cmd,&result, &nRow, &nCol, &errmsg);  

            printf("nRow = %d\n", nRow);  
            printf("nCol = %d\n", nCol);  
            if(nRow >= 1)
            {
                int i=0;
                int j=0;
                for (i = 0; i < nRow+1; i++)//0 1  2  
                {  
                    for (j = 0; j < nCol; j++)  
                    {  
                        printf("%s ", result[j+i*nCol] );  
                    }  
                    printf("\n");  
                } 
                gtk_widget_hide_all(window2);
                gtk_widget_show_all(window);
                gtk_entry_set_text(GTK_ENTRY(entry), rfid_buf);
                
            }
            else
            {
                gtk_widget_hide_all(window);
                gtk_widget_show_all(window2);
                //将获得银行卡号 写入卡号的输入框
                gtk_entry_set_text(GTK_ENTRY(entry_2), rfid_buf);
            }
        }
        
    }
}














int main(int argc, char *argv[])
{
	int ret1 = sqlite3_open("users.db",&db);
	if (ret1 != SQLITE_OK)
	{
		perror("sqlite3_open");
		return 0;
	}


	gtk_init(&argc,&argv);
	window = gtk_window_new(GTK_WINDOW_TOPLEVEL); 

	gtk_widget_set_size_request(window,1080,600);

	g_signal_connect(window,"destroy",G_CALLBACK(gtk_main_quit),NULL);

	GtkWidget * fixed = gtk_fixed_new();
	gtk_container_add(GTK_CONTAINER(window),fixed);
	GtkWidget * image = gtk_image_new_from_pixbuf(NULL);
	load_image(image,"imgs/background.jpg",1080,600); 
	gtk_fixed_put(GTK_FIXED(fixed),image,0,0);

	

	//创建标签：label
	label = gtk_label_new("Library Management");
	gtk_fixed_put(GTK_FIXED(fixed),label,320,50);
	label1 = gtk_label_new("图书馆管理平台");
	gtk_fixed_put(GTK_FIXED(fixed),label1,370,120);
	//颜色编码  red green blue
	sungtk_widget_set_font_size(label,35,FALSE);
	sungtk_widget_set_font_color(label,"green",FALSE);	
	sungtk_widget_set_font_size(label1,35,FALSE);
	sungtk_widget_set_font_color(label1,"green",FALSE);	

	label2 = gtk_label_new("学号：");
	gtk_fixed_put(GTK_FIXED(fixed),label2,285,302);
	label3 = gtk_label_new("密码：");
	gtk_fixed_put(GTK_FIXED(fixed),label3,560,302);
    
	//颜色编码  red green blue
	sungtk_widget_set_font_size(label2,15,FALSE);
	sungtk_widget_set_font_color(label2,"green",FALSE);	
	sungtk_widget_set_font_size(label3,15,FALSE);
	sungtk_widget_set_font_color(label3,"green",FALSE);	


	label4 = gtk_label_new("");
	gtk_fixed_put(GTK_FIXED(fixed),label4,450,260);
	sungtk_widget_set_font_size(label4,15,FALSE);
	sungtk_widget_set_font_color(label4,"red",FALSE);
	//行编辑：entry  没有参数 
	entry = gtk_entry_new();
	gtk_fixed_put(GTK_FIXED(fixed),entry,340,300);

	GtkWidget * image1 = gtk_image_new_from_pixbuf(NULL);
	load_image(image1,"imgs/r_user.jpg",28,28);
	gtk_fixed_put(GTK_FIXED(fixed),image1,502,300);

	GtkWidget * image2 = gtk_image_new_from_pixbuf(NULL);
	load_image(image2,"imgs/lock.jpg",28,28);
	gtk_fixed_put(GTK_FIXED(fixed),image2,777,300);

	entry1 = gtk_entry_new();
	gtk_fixed_put(GTK_FIXED(fixed),entry1,615,300);
    gtk_entry_set_visibility(GTK_ENTRY(entry1),FALSE);//----是否可视-密码效果

	GtkWidget * button_r1 = gtk_button_new_with_label("忘记密码？");
	gtk_widget_set_size_request(button_r1,85,35);
	gtk_fixed_put(GTK_FIXED(fixed),button_r1,335,340);
    gtk_button_set_relief(GTK_BUTTON(button_r1), GTK_RELIEF_NONE);//把按钮设置为透明
    g_signal_connect(button_r1,"pressed",G_CALLBACK(forget),NULL);

    GtkWidget * button_r2 = gtk_button_new_with_label("立即注册！");
	gtk_widget_set_size_request(button_r2,85,35);
	gtk_fixed_put(GTK_FIXED(fixed),button_r2,610,340);
    gtk_button_set_relief(GTK_BUTTON(button_r2), GTK_RELIEF_NONE);//把按钮设置为透明
    g_signal_connect(button_r2,"pressed",G_CALLBACK(reg),NULL);



	GtkWidget * button = gtk_button_new();	
	GtkWidget * img_btn = gtk_image_new_from_pixbuf(NULL);
	load_image(img_btn,"imgs/login.jpg",100,100);
	gtk_button_set_image(GTK_BUTTON(button),img_btn);
	gtk_fixed_put(GTK_FIXED(fixed),button,480,380);
    gtk_button_set_relief(GTK_BUTTON(button), GTK_RELIEF_NONE);//把按钮设置为透明

	g_signal_connect(button,"pressed",G_CALLBACK(login),NULL);


//第二个窗口,忘记密码
	window1 = gtk_window_new(GTK_WINDOW_TOPLEVEL);
    gtk_widget_set_size_request(window1,1080,600);
	g_signal_connect(window1,"destroy",G_CALLBACK(gtk_main_quit),NULL);

	GtkWidget * fixed1 = gtk_fixed_new();
	gtk_container_add(GTK_CONTAINER(window1),fixed1);
	GtkWidget * image_1 = gtk_image_new_from_pixbuf(NULL);
	load_image(image_1,"imgs/background.jpg",1080,600); 
	gtk_fixed_put(GTK_FIXED(fixed1),image_1,0,0);


    GtkWidget * button_n1 = gtk_button_new();	//返回主页面
    GtkWidget * img_btn_n1 = gtk_image_new_from_pixbuf(NULL);
    load_image(img_btn_n1,"imgs/返回.png",20,20);
    gtk_button_set_image(GTK_BUTTON(button_n1),img_btn_n1);
    gtk_fixed_put(GTK_FIXED(fixed1),button_n1,5,5);
    gtk_button_set_relief(GTK_BUTTON(button_n1), GTK_RELIEF_NONE);//把按钮设置为透明
    g_signal_connect(button_n1,"pressed",G_CALLBACK(back_n1),NULL);


	//创建标签：label
	label_1 = gtk_label_new("Library Management");
	gtk_fixed_put(GTK_FIXED(fixed1),label_1,320,50);
	label_11 = gtk_label_new("图书馆管理平台");
	gtk_fixed_put(GTK_FIXED(fixed1),label_11,370,120);
	//颜色编码  red green blue
	sungtk_widget_set_font_size(label_1,35,FALSE);
	sungtk_widget_set_font_color(label_1,"green",FALSE);	
	sungtk_widget_set_font_size(label_11,35,FALSE);
	sungtk_widget_set_font_color(label_11,"green",FALSE);	

	label_12 = gtk_label_new("学号：");
	gtk_fixed_put(GTK_FIXED(fixed1),label_12,185,302);
	label_13 = gtk_label_new("新密码：");
	gtk_fixed_put(GTK_FIXED(fixed1),label_13,445,302);
	label_14 = gtk_label_new("确认密码：");
	gtk_fixed_put(GTK_FIXED(fixed1),label_14,720,302);
	//颜色编码  red green blue
	sungtk_widget_set_font_size(label_12,15,FALSE);
	sungtk_widget_set_font_color(label_12,"green",FALSE);	
	sungtk_widget_set_font_size(label_13,15,FALSE);
	sungtk_widget_set_font_color(label_13,"green",FALSE);	
	sungtk_widget_set_font_size(label_14,15,FALSE);
	sungtk_widget_set_font_color(label_14,"green",FALSE);

	label_15 = gtk_label_new("");
	gtk_fixed_put(GTK_FIXED(fixed1),label_15,450,260);
	sungtk_widget_set_font_size(label_15,15,FALSE);
	sungtk_widget_set_font_color(label_15,"red",FALSE);
	//行编辑：entry  没有参数 
	entry_1 = gtk_entry_new();
	gtk_fixed_put(GTK_FIXED(fixed1),entry_1,240,300);
	entry_11 = gtk_entry_new();
	gtk_fixed_put(GTK_FIXED(fixed1),entry_11,515,300);
    gtk_entry_set_visibility(GTK_ENTRY(entry_11),FALSE);//----是否可视-密码效果
	entry_12 = gtk_entry_new();
	gtk_fixed_put(GTK_FIXED(fixed1),entry_12,806,300);
    gtk_entry_set_visibility(GTK_ENTRY(entry_12),FALSE);//----是否可视-密码效果

	GtkWidget * image_11 = gtk_image_new_from_pixbuf(NULL);
	load_image(image_11,"imgs/r_user.jpg",28,28);
	gtk_fixed_put(GTK_FIXED(fixed1),image_11,402,300);

	GtkWidget * image_12 = gtk_image_new_from_pixbuf(NULL);
	load_image(image_12,"imgs/lock.jpg",28,28);
	gtk_fixed_put(GTK_FIXED(fixed1),image_12,677,300);

	GtkWidget * image_13 = gtk_image_new_from_pixbuf(NULL);
	load_image(image_13,"imgs/phone.jpg",28,28);
	gtk_fixed_put(GTK_FIXED(fixed1),image_13,968,300);

	GtkWidget * button_1 = gtk_button_new();	
	GtkWidget * img_btn_1 = gtk_image_new_from_pixbuf(NULL);
	load_image(img_btn_1,"imgs/login.jpg",100,100);
	gtk_button_set_image(GTK_BUTTON(button_1),img_btn_1);
	gtk_fixed_put(GTK_FIXED(fixed1),button_1,480,380);
    gtk_button_set_relief(GTK_BUTTON(button_1), GTK_RELIEF_NONE);//把按钮设置为透明

	g_signal_connect(button_1,"pressed",G_CALLBACK(login_back1),NULL);
//第三个窗口,注册界面
	window2 = gtk_window_new(GTK_WINDOW_TOPLEVEL);
	gtk_widget_set_size_request(window2,1080,600);
	g_signal_connect(window2,"destroy",G_CALLBACK(gtk_main_quit),NULL);

	GtkWidget * fixed2 = gtk_fixed_new();
	gtk_container_add(GTK_CONTAINER(window2),fixed2);
	GtkWidget * image_2 = gtk_image_new_from_pixbuf(NULL);
	load_image(image_2,"imgs/background.jpg",1080,600); 
	gtk_fixed_put(GTK_FIXED(fixed2),image_2,0,0);


    GtkWidget * button_n = gtk_button_new();	//返回主页面
    GtkWidget * img_btn_n = gtk_image_new_from_pixbuf(NULL);
    load_image(img_btn_n,"imgs/返回.png",20,20);
    gtk_button_set_image(GTK_BUTTON(button_n),img_btn_n);
    gtk_fixed_put(GTK_FIXED(fixed2),button_n,5,5);
    gtk_button_set_relief(GTK_BUTTON(button_n), GTK_RELIEF_NONE);//把按钮设置为透明
    g_signal_connect(button_n,"pressed",G_CALLBACK(back_n),NULL);


	//创建标签：label
	label_2 = gtk_label_new("Library Management");
	gtk_fixed_put(GTK_FIXED(fixed2),label_2,320,50);
	label_21 = gtk_label_new("图书馆管理平台");
	gtk_fixed_put(GTK_FIXED(fixed2),label_21,370,120);
	//颜色编码  red green blue
	sungtk_widget_set_font_size(label_2,35,FALSE);
	sungtk_widget_set_font_color(label_2,"green",FALSE);	
	sungtk_widget_set_font_size(label_21,35,FALSE);
	sungtk_widget_set_font_color(label_21,"green",FALSE);	

	label_22 = gtk_label_new("学号：");
	gtk_fixed_put(GTK_FIXED(fixed2),label_22,185,302);
	label_23 = gtk_label_new("密码：");
	gtk_fixed_put(GTK_FIXED(fixed2),label_23,460,302);
	label_24 = gtk_label_new("手机号：");
	gtk_fixed_put(GTK_FIXED(fixed2),label_24,735,302);
	//颜色编码  red green blue
	sungtk_widget_set_font_size(label_22,15,FALSE);
	sungtk_widget_set_font_color(label_22,"green",FALSE);	
	sungtk_widget_set_font_size(label_23,15,FALSE);
	sungtk_widget_set_font_color(label_23,"green",FALSE);	
	sungtk_widget_set_font_size(label_24,15,FALSE);
	sungtk_widget_set_font_color(label_24,"green",FALSE);

	label_25 = gtk_label_new("");
	gtk_fixed_put(GTK_FIXED(fixed2),label_25,450,260);
	sungtk_widget_set_font_size(label_25,15,FALSE);
	sungtk_widget_set_font_color(label_25,"red",FALSE);
	//行编辑：entry  没有参数 
	entry_2 = gtk_entry_new();
	gtk_fixed_put(GTK_FIXED(fixed2),entry_2,240,300);
	entry_21 = gtk_entry_new();
	gtk_fixed_put(GTK_FIXED(fixed2),entry_21,515,300);
    gtk_entry_set_visibility(GTK_ENTRY(entry_21),FALSE);//----是否可视-密码效果
	entry_22 = gtk_entry_new();
	gtk_fixed_put(GTK_FIXED(fixed2),entry_22,806,300);

	GtkWidget * image_21 = gtk_image_new_from_pixbuf(NULL);
	load_image(image_21,"imgs/r_user.jpg",28,28);
	gtk_fixed_put(GTK_FIXED(fixed2),image_21,402,300);

	GtkWidget * image_22 = gtk_image_new_from_pixbuf(NULL);
	load_image(image_22,"imgs/lock.jpg",28,28);
	gtk_fixed_put(GTK_FIXED(fixed2),image_22,677,300);

	GtkWidget * image_23 = gtk_image_new_from_pixbuf(NULL);
	load_image(image_23,"imgs/phone.jpg",28,28);
	gtk_fixed_put(GTK_FIXED(fixed2),image_23,968,300);

	GtkWidget * button_2 = gtk_button_new();	
	GtkWidget * img_btn_2 = gtk_image_new_from_pixbuf(NULL);
	load_image(img_btn_2,"imgs/login.jpg",100,100);
	gtk_button_set_image(GTK_BUTTON(button_2),img_btn_2);
	gtk_fixed_put(GTK_FIXED(fixed2),button_2,480,380);
    gtk_button_set_relief(GTK_BUTTON(button_2), GTK_RELIEF_NONE);//把按钮设置为透明

	g_signal_connect(button_2,"pressed",G_CALLBACK(login_back),NULL);



// 第4个窗口---------------------主页-------------
    window3 = gtk_window_new(GTK_WINDOW_TOPLEVEL);
	gtk_widget_set_size_request(window3,1080,600);
	g_signal_connect(window3,"destroy",G_CALLBACK(gtk_main_quit),NULL);

	GtkWidget * fixed3 = gtk_fixed_new();
	gtk_container_add(GTK_CONTAINER(window3),fixed3);

    GtkWidget * button_g0 = gtk_button_new();	
	GtkWidget * img_btn_g0 = gtk_image_new_from_pixbuf(NULL);
	load_image(img_btn_g0,"imgs/head.jpg",1080,100);
	gtk_button_set_image(GTK_BUTTON(button_g0),img_btn_g0);
	gtk_fixed_put(GTK_FIXED(fixed3),button_g0,0,0);
    gtk_button_set_relief(GTK_BUTTON(button_g0), GTK_RELIEF_NONE);//把按钮设置为透明
	g_signal_connect(button_g0,"pressed",G_CALLBACK(header),NULL);

	

	GtkWidget * image_g1 = gtk_image_new_from_pixbuf(NULL);
	load_image(image_g1,"imgs/background.jpg",1080,500);  
	gtk_fixed_put(GTK_FIXED(fixed3),image_g1,0,100);

    label_g1 = gtk_label_new("个人中心");
	gtk_fixed_put(GTK_FIXED(fixed3),label_g1,213,345);
	sungtk_widget_set_font_size(label_g1,15,FALSE);
	label_g2 = gtk_label_new("图书借阅系统");
	gtk_fixed_put(GTK_FIXED(fixed3),label_g2,458,345);
	sungtk_widget_set_font_size(label_g2,15,FALSE);

	label_g4 = gtk_label_new("座位预约系统");
	gtk_fixed_put(GTK_FIXED(fixed3),label_g4,719,345);
	sungtk_widget_set_font_size(label_g4,15,FALSE);


    //----------user
	GtkWidget * button_g7 = gtk_button_new();	
	GtkWidget * img_btn_g7 = gtk_image_new_from_pixbuf(NULL);
	load_image(img_btn_g7,"imgs/user.jpg",100,100);
	gtk_button_set_image(GTK_BUTTON(button_g7),img_btn_g7);
	gtk_fixed_put(GTK_FIXED(fixed3),button_g7,200,235);
    gtk_button_set_relief(GTK_BUTTON(button_g7), GTK_RELIEF_NONE);//把按钮设置为透明
	g_signal_connect(button_g7,"pressed",G_CALLBACK(user),NULL);

        //-----------借阅
	GtkWidget * button_g1 = gtk_button_new();	
	GtkWidget * img_btn_g1 = gtk_image_new_from_pixbuf(NULL);
	load_image(img_btn_g1,"imgs/system.jpg",100,100);
	gtk_button_set_image(GTK_BUTTON(button_g1),img_btn_g1);
	gtk_fixed_put(GTK_FIXED(fixed3),button_g1,460,235);
    gtk_button_set_relief(GTK_BUTTON(button_g1), GTK_RELIEF_NONE);//把按钮设置为透明
	g_signal_connect(button_g1,"pressed",G_CALLBACK(book_system),NULL);




    //-----------预约
	GtkWidget * button_g4 = gtk_button_new();	
	GtkWidget * img_btn_g4 = gtk_image_new_from_pixbuf(NULL);
	load_image(img_btn_g4,"imgs/system.jpg",100,100);
	gtk_button_set_image(GTK_BUTTON(button_g4),img_btn_g4);
	gtk_fixed_put(GTK_FIXED(fixed3),button_g4,720,235);
    gtk_button_set_relief(GTK_BUTTON(button_g4), GTK_RELIEF_NONE);//把按钮设置为透明
	g_signal_connect(button_g4,"pressed",G_CALLBACK(seat_system),NULL);













//------窗口---------------------个人中心-------------
    ////////////////////分主页面----------------------
    window_z = gtk_window_new(GTK_WINDOW_TOPLEVEL);  // * window 中的window是变量,括号内的是属性设置：边框
	// 控件 gtk  widget
	gtk_widget_set_size_request(window_z,1080,600);
	//点X程序退出
	g_signal_connect(window_z,"destroy",G_CALLBACK(gtk_main_quit),NULL);
	// 创建固定布局
	fixed_z = gtk_fixed_new();
	gtk_container_add(GTK_CONTAINER(window_z),fixed_z);

	//创建图片控件 放置背景图片
	GtkWidget * image_z = gtk_image_new_from_pixbuf(NULL);
	load_image(image_z,"imgs/background.jpg",1080,600);  //引号里面是路径,  如果在当前文件夹就直接是名字
	gtk_fixed_put(GTK_FIXED(fixed_z),image_z,0,0);



    GtkWidget * button_n4 = gtk_button_new();	//返回主页面
    GtkWidget * img_btn_n4 = gtk_image_new_from_pixbuf(NULL);
    load_image(img_btn_n4,"imgs/返回.png",20,20);
    gtk_button_set_image(GTK_BUTTON(button_n4),img_btn_n4);
    gtk_fixed_put(GTK_FIXED(fixed_z),button_n4,5,5);
    gtk_button_set_relief(GTK_BUTTON(button_n4), GTK_RELIEF_NONE);//把按钮设置为透明
    g_signal_connect(button_n4,"pressed",G_CALLBACK(back_n4),NULL);



    //放置个人中心头像图片
	GtkWidget * image_z1 = gtk_image_new_from_pixbuf(NULL);
	load_image(image_z1,"imgs/1.png",100,100);
	gtk_fixed_put(GTK_FIXED(fixed_z),image_z1,490,50);


    label_z1=gtk_label_new("学号");
    gtk_fixed_put(GTK_FIXED(fixed_z),label_z1,350,200);
    sungtk_widget_set_font_size(label_z1,25,FALSE);
    sungtk_widget_set_font_color(label_z1,"#000000",FALSE);

    // entry_z1 =gtk_entry_new();
    // gtk_fixed_put(GTK_FIXED(fixed_z),entry_z1,500,200);



    label_z2=gtk_label_new("手机号");
    gtk_fixed_put(GTK_FIXED(fixed_z),label_z2,350,300);
    sungtk_widget_set_font_size(label_z2,25,FALSE);
    sungtk_widget_set_font_color(label_z2,"#000000",FALSE);

    // entry_z2 =gtk_entry_new();
    // gtk_fixed_put(GTK_FIXED(fixed_z),entry_z2,500,300);


    
    GtkWidget * chongzhi_button_z = gtk_button_new_with_label("修改密码");
    gtk_fixed_put(GTK_FIXED(fixed_z),chongzhi_button_z,500,420);
    sungtk_widget_set_font_size(chongzhi_button_z,30,FALSE);
    sungtk_widget_set_font_color(chongzhi_button_z,"#000000",FALSE);
	g_signal_connect(chongzhi_button_z,"pressed",G_CALLBACK(chongzhi),NULL);

	GtkWidget * tuichu_button_z = gtk_button_new_with_label("退出登录");
    gtk_fixed_put(GTK_FIXED(fixed_z),tuichu_button_z,500,500);
    sungtk_widget_set_font_size(tuichu_button_z,30,FALSE);
    sungtk_widget_set_font_color(tuichu_button_z,"#000000",FALSE);
	g_signal_connect(tuichu_button_z,"pressed",G_CALLBACK(tuichu),NULL);

/////////////////---------------------------修改页面
    windowz_1 = gtk_window_new(GTK_WINDOW_TOPLEVEL);
    gtk_widget_set_size_request(windowz_1,1080,600);
	g_signal_connect(windowz_1,"destroy",G_CALLBACK(gtk_main_quit),NULL);

	GtkWidget * fixed_z1 = gtk_fixed_new();
	gtk_container_add(GTK_CONTAINER(windowz_1),fixed_z1);
	GtkWidget * image_z10 = gtk_image_new_from_pixbuf(NULL);
	load_image(image_z10,"imgs/background.jpg",1080,600); 
	gtk_fixed_put(GTK_FIXED(fixed_z1),image_z10,0,0);


    GtkWidget * button_n5 = gtk_button_new();	//返回主页面
    GtkWidget * img_btn_n5 = gtk_image_new_from_pixbuf(NULL);
    load_image(img_btn_n5,"imgs/返回.png",20,20);
    gtk_button_set_image(GTK_BUTTON(button_n5),img_btn_n5);
    gtk_fixed_put(GTK_FIXED(fixed_z1),button_n5,5,5);
    gtk_button_set_relief(GTK_BUTTON(button_n5), GTK_RELIEF_NONE);//把按钮设置为透明
    g_signal_connect(button_n5,"pressed",G_CALLBACK(back_n5),NULL);


	//创建标签：label
	label_z1 = gtk_label_new("Library Management");
	gtk_fixed_put(GTK_FIXED(fixed_z1),label_z1,320,50);
	label_z11 = gtk_label_new("图书馆管理平台");
	gtk_fixed_put(GTK_FIXED(fixed_z1),label_z11,370,120);
	//颜色编码  red green blue
	sungtk_widget_set_font_size(label_z1,35,FALSE);
	sungtk_widget_set_font_color(label_z1,"green",FALSE);	
	sungtk_widget_set_font_size(label_z11,35,FALSE);
	sungtk_widget_set_font_color(label_z11,"green",FALSE);	

	label_z12 = gtk_label_new("旧密码：");
	gtk_fixed_put(GTK_FIXED(fixed_z1),label_z12,172,302);
	label_z13 = gtk_label_new("新密码：");
	gtk_fixed_put(GTK_FIXED(fixed_z1),label_z13,445,302);
	label_z14 = gtk_label_new("确认密码：");
	gtk_fixed_put(GTK_FIXED(fixed_z1),label_z14,720,302);
	//颜色编码  red green blue
	sungtk_widget_set_font_size(label_z12,15,FALSE);
	sungtk_widget_set_font_color(label_z12,"green",FALSE);	
	sungtk_widget_set_font_size(label_z13,15,FALSE);
	sungtk_widget_set_font_color(label_z13,"green",FALSE);	
	sungtk_widget_set_font_size(label_z14,15,FALSE);
	sungtk_widget_set_font_color(label_z14,"green",FALSE);

	label_z15 = gtk_label_new("");
	gtk_fixed_put(GTK_FIXED(fixed_z1),label_z15,450,260);
	sungtk_widget_set_font_size(label_z15,15,FALSE);
	sungtk_widget_set_font_color(label_z15,"red",FALSE);
	//行编辑：entry  没有参数 
	entry_z1 = gtk_entry_new();
	gtk_fixed_put(GTK_FIXED(fixed_z1),entry_z1,240,300);
    gtk_entry_set_visibility(GTK_ENTRY(entry_z1),FALSE);//----是否可视-密码效果
	entry_z11 = gtk_entry_new();
	gtk_fixed_put(GTK_FIXED(fixed_z1),entry_z11,515,300);
    gtk_entry_set_visibility(GTK_ENTRY(entry_z11),FALSE);//----是否可视-密码效果
	entry_z12 = gtk_entry_new();
	gtk_fixed_put(GTK_FIXED(fixed_z1),entry_z12,806,300);
    gtk_entry_set_visibility(GTK_ENTRY(entry_z12),FALSE);//----是否可视-密码效果

	GtkWidget * image_z11 = gtk_image_new_from_pixbuf(NULL);
	load_image(image_z11,"imgs/lock.jpg",28,28);
	gtk_fixed_put(GTK_FIXED(fixed_z1),image_z11,402,300);

	GtkWidget * image_z12 = gtk_image_new_from_pixbuf(NULL);
	load_image(image_z12,"imgs/lock.jpg",28,28);
	gtk_fixed_put(GTK_FIXED(fixed_z1),image_z12,677,300);

	GtkWidget * image_z13 = gtk_image_new_from_pixbuf(NULL);
	load_image(image_z13,"imgs/lock.jpg",28,28);
	gtk_fixed_put(GTK_FIXED(fixed_z1),image_z13,968,300);

	GtkWidget * button_z1 = gtk_button_new();	
	GtkWidget * img_btn_z1 = gtk_image_new_from_pixbuf(NULL);
	load_image(img_btn_z1,"imgs/login.jpg",100,100);
	gtk_button_set_image(GTK_BUTTON(button_z1),img_btn_z1);
	gtk_fixed_put(GTK_FIXED(fixed_z1),button_z1,480,380);
    gtk_button_set_relief(GTK_BUTTON(button_z1), GTK_RELIEF_NONE);//把按钮设置为透明

	g_signal_connect(button_z1,"pressed",G_CALLBACK(login_back5),NULL);


//
//------窗口---------------------图书借阅系统-------------
    //-------------分主页面--------------
    window_y1 = gtk_window_new(GTK_WINDOW_TOPLEVEL); 
    int ret2 = sqlite3_open("library.db",&db_y);
	if (ret2 != SQLITE_OK)
	{
		perror("sqlite3_open");
		return 0;
	}
	gtk_widget_set_size_request(window_y1,1080,600);

	g_signal_connect(window_y1,"destroy",G_CALLBACK(gtk_main_quit),NULL);

	GtkWidget * fixed_y1 = gtk_fixed_new();
	gtk_container_add(GTK_CONTAINER(window_y1),fixed_y1);
	GtkWidget * image_y1 = gtk_image_new_from_pixbuf(NULL);
	load_image(image_y1,"imgs/background.jpg",1080,600); 
	gtk_fixed_put(GTK_FIXED(fixed_y1),image_y1,0,0);

    label_y1 = gtk_label_new("欢迎来到图书借阅系统！");
 	gtk_fixed_put(GTK_FIXED(fixed_y1),label_y1,0,0);
 	sungtk_widget_set_font_size(label_y1,35,FALSE);
 	sungtk_widget_set_font_color(label_y1,"blue",FALSE);
	button_y1 = gtk_button_new_with_label("根据图书编号借阅");
	gtk_fixed_put(GTK_FIXED(fixed_y1),button_y1,300,50);
	g_signal_connect(button_y1,"pressed",G_CALLBACK(chaxun1),NULL);
	sungtk_widget_set_font_size(button_y1,35,TRUE);
	button_y2 = gtk_button_new_with_label("根据图书名字借阅");
	gtk_fixed_put(GTK_FIXED(fixed_y1),button_y2,300,150);
	g_signal_connect(button_y2,"pressed",G_CALLBACK(chaxun2),NULL);
	sungtk_widget_set_font_size(button_y2,35,TRUE);
	button_y3 = gtk_button_new_with_label("根据图书作者借阅");
	gtk_fixed_put(GTK_FIXED(fixed_y1),button_y3,300,250);
	g_signal_connect(button_y3,"pressed",G_CALLBACK(chaxun3),NULL);
	sungtk_widget_set_font_size(button_y3,35,TRUE);
	button_y21 = gtk_button_new_with_label("查看正借阅的图书");
	gtk_fixed_put(GTK_FIXED(fixed_y1),button_y21,300,350);
	g_signal_connect(button_y21,"pressed",G_CALLBACK(lishi),NULL);
	sungtk_widget_set_font_size(button_y21,35,TRUE);
	button_y17 = gtk_button_new_with_label("向图书馆捐赠图书");
	gtk_fixed_put(GTK_FIXED(fixed_y1),button_y17,300,450);
	g_signal_connect(button_y17,"pressed",G_CALLBACK(juanzeng),NULL);
	sungtk_widget_set_font_size(button_y17,35,TRUE);





    GtkWidget * button_n2 = gtk_button_new();	//返回主页面
    GtkWidget * img_btn_n2 = gtk_image_new_from_pixbuf(NULL);
    load_image(img_btn_n2,"imgs/返回.png",20,20);
    gtk_button_set_image(GTK_BUTTON(button_n2),img_btn_n2);
    gtk_fixed_put(GTK_FIXED(fixed_y1),button_n2,5,5);
    gtk_button_set_relief(GTK_BUTTON(button_n2), GTK_RELIEF_NONE);//把按钮设置为透明
    g_signal_connect(button_n2,"pressed",G_CALLBACK(back_n2),NULL);




    //-------------分页面1--------------
    window_y2 = gtk_window_new(GTK_WINDOW_TOPLEVEL);
	gtk_widget_set_size_request(window_y2,1080,600);
	//点X程序退出
	g_signal_connect(window_y2,"destroy",G_CALLBACK(gtk_main_quit),NULL);

	// 创建固定布局
	fixed_y2 = gtk_fixed_new();
	gtk_container_add(GTK_CONTAINER(window_y2),fixed_y2);

	//创建按钮
	image_y = gtk_image_new_from_pixbuf(NULL);
	load_image(image_y,"imgs/background.jpg",1080,600);
	gtk_fixed_put(GTK_FIXED(fixed_y2),image_y,0,0);
	label_y3 = gtk_label_new("请输入你需要借阅的图书编号：");
	gtk_fixed_put(GTK_FIXED(fixed_y2),label_y3,200,150);
	sungtk_widget_set_font_size(label_y3,20,FALSE);
	entry_y = gtk_entry_new();
	gtk_fixed_put(GTK_FIXED(fixed_y2),entry_y,350,200);
	gtk_entry_set_text(GTK_ENTRY(entry_y),"");
	button_y7 = gtk_button_new_with_label("查询");
	gtk_fixed_put(GTK_FIXED(fixed_y2),button_y7,200,450);
	g_signal_connect(button_y7,"pressed",G_CALLBACK(chaxunid),NULL);
	sungtk_widget_set_font_size(button_y7,35,TRUE);
	button_y8 = gtk_button_new_with_label("借阅");
	gtk_fixed_put(GTK_FIXED(fixed_y2),button_y8,350,450);
	g_signal_connect(button_y8,"pressed",G_CALLBACK(selectfromid),NULL);
	sungtk_widget_set_font_size(button_y8,35,TRUE);
	button_y9 = gtk_button_new_with_label("还书");
	gtk_fixed_put(GTK_FIXED(fixed_y2),button_y9,500,450);
	g_signal_connect(button_y9,"pressed",G_CALLBACK(backfromid),NULL);
	sungtk_widget_set_font_size(button_y9,35,TRUE);
	button_y10 = gtk_button_new_with_label("返回");
	gtk_fixed_put(GTK_FIXED(fixed_y2),button_y10,650,450);
	g_signal_connect(button_y10,"pressed",G_CALLBACK(back2),NULL);
	sungtk_widget_set_font_size(button_y10,35,TRUE);
	label_y6 = gtk_label_new("");
	gtk_fixed_put(GTK_FIXED(fixed_y2),label_y6,175,300);
	sungtk_widget_set_font_size(label_y6,25,FALSE);
	label_y7 = gtk_label_new("");
	gtk_fixed_put(GTK_FIXED(fixed_y2),label_y7,275,300);
	sungtk_widget_set_font_size(label_y7,25,FALSE);
	label_y8 = gtk_label_new("");
	gtk_fixed_put(GTK_FIXED(fixed_y2),label_y8,550,300);
	sungtk_widget_set_font_size(label_y8,25,FALSE);
	label_y9 = gtk_label_new("");
	gtk_fixed_put(GTK_FIXED(fixed_y2),label_y9,750,300);
	sungtk_widget_set_font_size(label_y9,25,FALSE);
	sungtk_widget_set_font_color(label_y9,"red",FALSE);


    //-------------分页面2--------------name查询页面
    window_y3 = gtk_window_new(GTK_WINDOW_TOPLEVEL);
	gtk_widget_set_size_request(window_y3,1080,600);
	//点X程序退出
	g_signal_connect(window_y3,"destroy",G_CALLBACK(gtk_main_quit),NULL);

	// 创建固定布局
	fixed_y3 = gtk_fixed_new();
	gtk_container_add(GTK_CONTAINER(window_y3),fixed_y3);

	//创建按钮
	image_y = gtk_image_new_from_pixbuf(NULL);
	load_image(image_y,"imgs/background.jpg",1080,600);
	gtk_fixed_put(GTK_FIXED(fixed_y3),image_y,0,0);
	label_y4 = gtk_label_new("请输入你需要借阅的图书名字：");
	gtk_fixed_put(GTK_FIXED(fixed_y3),label_y4,200,150);
	sungtk_widget_set_font_size(label_y4,20,FALSE);
	entry_y1 = gtk_entry_new();
	gtk_fixed_put(GTK_FIXED(fixed_y3),entry_y1,350,200);
	gtk_entry_set_text(GTK_ENTRY(entry_y1),"");
	button_y13 = gtk_button_new_with_label("查询");
	gtk_fixed_put(GTK_FIXED(fixed_y3),button_y13,200,450);
	g_signal_connect(button_y13,"pressed",G_CALLBACK(chaxunname),NULL);
	sungtk_widget_set_font_size(button_y13,35,TRUE);
	button_y11 = gtk_button_new_with_label("借阅");
	gtk_fixed_put(GTK_FIXED(fixed_y3),button_y11,350,450);
	g_signal_connect(button_y11,"pressed",G_CALLBACK(selectfromname),NULL);
	sungtk_widget_set_font_size(button_y11,35,TRUE);
	button_y14 = gtk_button_new_with_label("还书");
	gtk_fixed_put(GTK_FIXED(fixed_y3),button_y14,500,450);
	g_signal_connect(button_y14,"pressed",G_CALLBACK(backfromname),NULL);
	sungtk_widget_set_font_size(button_y14,35,TRUE);
	button_y12 = gtk_button_new_with_label("返回");
	gtk_fixed_put(GTK_FIXED(fixed_y3),button_y12,650,450);
	g_signal_connect(button_y12,"pressed",G_CALLBACK(back3),NULL);
	sungtk_widget_set_font_size(button_y12,35,TRUE);
	label_y10 = gtk_label_new("");
	gtk_fixed_put(GTK_FIXED(fixed_y3),label_y10,175,300);
	sungtk_widget_set_font_size(label_y10,30,FALSE);
	label_y11 = gtk_label_new("");
	gtk_fixed_put(GTK_FIXED(fixed_y3),label_y11,275,300);
	sungtk_widget_set_font_size(label_y11,30,FALSE);
	label_y12 = gtk_label_new("");
	gtk_fixed_put(GTK_FIXED(fixed_y3),label_y12,550,300);
	sungtk_widget_set_font_size(label_y12,30,FALSE);
	label_y13 = gtk_label_new("");
	gtk_fixed_put(GTK_FIXED(fixed_y3),label_y13,750,300);
	sungtk_widget_set_font_size(label_y13,30,FALSE);
	sungtk_widget_set_font_color(label_y13,"red",FALSE);
    //-------------分页面3--------------writer查询页面
    window_y4 = gtk_window_new(GTK_WINDOW_TOPLEVEL);
	gtk_widget_set_size_request(window_y4,1080,600);
	//点X程序退出
	g_signal_connect(window_y4,"destroy",G_CALLBACK(gtk_main_quit),NULL);

	// 创建固定布局
	fixed_y4 = gtk_fixed_new();
	gtk_container_add(GTK_CONTAINER(window_y4),fixed_y4);

	image_y = gtk_image_new_from_pixbuf(NULL);
	load_image(image_y,"imgs/background.jpg",1080,600);
	gtk_fixed_put(GTK_FIXED(fixed_y4),image_y,0,0);
	label_y5 = gtk_label_new("请输入你需要借阅的图书作者：");
	gtk_fixed_put(GTK_FIXED(fixed_y4),label_y5,200,150);
	sungtk_widget_set_font_size(label_y5,20,FALSE);
	entry_y2 = gtk_entry_new();
	gtk_fixed_put(GTK_FIXED(fixed_y4),entry_y2,350,200);
	gtk_entry_set_text(GTK_ENTRY(entry_y2),"");
	button_y15 = gtk_button_new_with_label("查询");
	gtk_fixed_put(GTK_FIXED(fixed_y4),button_y15,200,450);
	g_signal_connect(button_y15,"pressed",G_CALLBACK(chaxunwriter),NULL);
	sungtk_widget_set_font_size(button_y15,35,TRUE);
	button_y5 = gtk_button_new_with_label("借阅");
	gtk_fixed_put(GTK_FIXED(fixed_y4),button_y5,350,450);
	g_signal_connect(button_y5,"pressed",G_CALLBACK(selectfromwriter),NULL);
	sungtk_widget_set_font_size(button_y5,35,TRUE);
	button_y16 = gtk_button_new_with_label("还书");
	gtk_fixed_put(GTK_FIXED(fixed_y4),button_y16,500,450);
	g_signal_connect(button_y16,"pressed",G_CALLBACK(backfromwriter),NULL);
	sungtk_widget_set_font_size(button_y16,35,TRUE);
	button_y6 = gtk_button_new_with_label("返回");
	gtk_fixed_put(GTK_FIXED(fixed_y4),button_y6,650,450);
	g_signal_connect(button_y6,"pressed",G_CALLBACK(back4),NULL);
	sungtk_widget_set_font_size(button_y6,35,TRUE);
	label_y14 = gtk_label_new("");
	gtk_fixed_put(GTK_FIXED(fixed_y4),label_y14,175,300);
	sungtk_widget_set_font_size(label_y14,30,FALSE);
	label_y15 = gtk_label_new("");
	gtk_fixed_put(GTK_FIXED(fixed_y4),label_y15,275,300);
	sungtk_widget_set_font_size(label_y15,30,FALSE);
	label_y16 = gtk_label_new("");
	gtk_fixed_put(GTK_FIXED(fixed_y4),label_y16,550,300);
	sungtk_widget_set_font_size(label_y16,30,FALSE);
	label_y17 = gtk_label_new("");
	gtk_fixed_put(GTK_FIXED(fixed_y4),label_y17,750,300);
	sungtk_widget_set_font_size(label_y17,30,FALSE);
	sungtk_widget_set_font_color(label_y17,"red",FALSE);
    //-------------分页面4--------------
    window_y5 = gtk_window_new(GTK_WINDOW_TOPLEVEL);
	gtk_widget_set_size_request(window_y5,1080,600);
	//点X程序退出
	g_signal_connect(window_y5,"destroy",G_CALLBACK(gtk_main_quit),NULL);

	// 创建固定布局
	fixed_y5 = gtk_fixed_new();
	gtk_container_add(GTK_CONTAINER(window_y5),fixed_y5);
	image_y = gtk_image_new_from_pixbuf(NULL);
	load_image(image_y,"imgs/background.jpg",1080,600);
	gtk_fixed_put(GTK_FIXED(fixed_y5),image_y,0,0);
	label_y18 = gtk_label_new("欢迎您向图书馆捐赠图书！");
 	gtk_fixed_put(GTK_FIXED(fixed_y5),label_y18,50,50);
 	sungtk_widget_set_font_size(label_y18,35,FALSE);
 	sungtk_widget_set_font_color(label_y18,"blue",FALSE);
 	label_y19 = gtk_label_new("请输入你需要捐赠的图书编号：");
	gtk_fixed_put(GTK_FIXED(fixed_y5),label_y19,200,150);
	sungtk_widget_set_font_size(label_y19,20,FALSE);
	entry_y3 = gtk_entry_new();
	gtk_fixed_put(GTK_FIXED(fixed_y5),entry_y3,200,200);
	gtk_entry_set_text(GTK_ENTRY(entry_y3),"");
	label_y20 = gtk_label_new("请输入你需要捐赠的图书名字：");
	gtk_fixed_put(GTK_FIXED(fixed_y5),label_y20,200,250);
	sungtk_widget_set_font_size(label_y20,20,FALSE);
	entry_y4 = gtk_entry_new();
	gtk_fixed_put(GTK_FIXED(fixed_y5),entry_y4,200,300);
	gtk_entry_set_text(GTK_ENTRY(entry_y4),"");
	label_y21 = gtk_label_new("请输入你需要捐赠的图书作者：");
	gtk_fixed_put(GTK_FIXED(fixed_y5),label_y21,200,350);
	sungtk_widget_set_font_size(label_y21,20,FALSE);
	entry_y5 = gtk_entry_new();
	gtk_fixed_put(GTK_FIXED(fixed_y5),entry_y5,200,400);
	gtk_entry_set_text(GTK_ENTRY(entry_y5),"");
	button_y18 = gtk_button_new_with_label("返回");
	gtk_fixed_put(GTK_FIXED(fixed_y5),button_y18,850,450);
	g_signal_connect(button_y18,"pressed",G_CALLBACK(back5),NULL);
	sungtk_widget_set_font_size(button_y18,35,TRUE);
	button_y19 = gtk_button_new_with_label("捐赠");
	gtk_fixed_put(GTK_FIXED(fixed_y5),button_y19,700,450);
	g_signal_connect(button_y19,"pressed",G_CALLBACK(juanzengok),NULL);
	sungtk_widget_set_font_size(button_y19,35,TRUE);
	label_y21 = gtk_label_new("");
	gtk_fixed_put(GTK_FIXED(fixed_y5),label_y21,200,450);
	sungtk_widget_set_font_size(label_y21,20,FALSE);
	sungtk_widget_set_font_color(label_y21,"red",FALSE);

    window_y6 = gtk_window_new(GTK_WINDOW_TOPLEVEL);
	gtk_widget_set_size_request(window_y6,1080,600);
	//点X程序退出
	g_signal_connect(window_y6,"destroy",G_CALLBACK(gtk_main_quit),NULL);

	// 创建固定布局
	fixed_y6 = gtk_fixed_new();
	gtk_container_add(GTK_CONTAINER(window_y6),fixed_y6);
	image_y = gtk_image_new_from_pixbuf(NULL);
	load_image(image_y,"imgs/123.png",1080,600);
	gtk_fixed_put(GTK_FIXED(fixed_y6),image_y,0,0);
	button_y22 = gtk_button_new_with_label("返回");
	gtk_fixed_put(GTK_FIXED(fixed_y6),button_y22,750,450);
	g_signal_connect(button_y22,"pressed",G_CALLBACK(back6),NULL);
	sungtk_widget_set_font_size(button_y22,35,TRUE);
	button_y23 = gtk_button_new_with_label("查询");
	gtk_fixed_put(GTK_FIXED(fixed_y6),button_y23,600,450);
	g_signal_connect(button_y23,"pressed",G_CALLBACK(chaxunlishi),NULL);
	sungtk_widget_set_font_size(button_y23,35,TRUE);
	label_y22 = gtk_label_new("编号");
	gtk_fixed_put(GTK_FIXED(fixed_y6),label_y22,175,100);
	sungtk_widget_set_font_size(label_y22,30,FALSE);
	label_y23 = gtk_label_new("书名");
	gtk_fixed_put(GTK_FIXED(fixed_y6),label_y23,275,100);
	sungtk_widget_set_font_size(label_y23,30,FALSE);
	label_y24 = gtk_label_new("作者");
	gtk_fixed_put(GTK_FIXED(fixed_y6),label_y24,550,100);
	sungtk_widget_set_font_size(label_y24,30,FALSE);
	label_y25 = gtk_label_new("状态");
	gtk_fixed_put(GTK_FIXED(fixed_y6),label_y25,750,100);
	sungtk_widget_set_font_size(label_y25,30,FALSE);
	
	label_y26 = gtk_label_new("");
	gtk_fixed_put(GTK_FIXED(fixed_y6),label_y26,175,200);
	sungtk_widget_set_font_size(label_y26,30,FALSE);
	label_y27 = gtk_label_new("");
	gtk_fixed_put(GTK_FIXED(fixed_y6),label_y27,275,200);
	sungtk_widget_set_font_size(label_y27,30,FALSE);
	label_y28 = gtk_label_new("");
	gtk_fixed_put(GTK_FIXED(fixed_y6),label_y28,550,200);
	sungtk_widget_set_font_size(label_y28,30,FALSE);
	label_y29 = gtk_label_new("");
	gtk_fixed_put(GTK_FIXED(fixed_y6),label_y29,750,200);
	sungtk_widget_set_font_size(label_y29,30,FALSE);
	sungtk_widget_set_font_color(label_y29,"red",FALSE);
	
	label_y30 = gtk_label_new("");
	gtk_fixed_put(GTK_FIXED(fixed_y6),label_y30,175,300);
	sungtk_widget_set_font_size(label_y30,30,FALSE);
	label_y31 = gtk_label_new("");
	gtk_fixed_put(GTK_FIXED(fixed_y6),label_y31,275,300);
	sungtk_widget_set_font_size(label_y31,30,FALSE);
	label_y32 = gtk_label_new("");
	gtk_fixed_put(GTK_FIXED(fixed_y6),label_y32,550,300);
	sungtk_widget_set_font_size(label_y32,30,FALSE);
	label_y33 = gtk_label_new("");
	gtk_fixed_put(GTK_FIXED(fixed_y6),label_y33,750,300);
	sungtk_widget_set_font_size(label_y33,30,FALSE);
	sungtk_widget_set_font_color(label_y33,"red",FALSE);
//

//------窗口-------------座位预约系统---------------------
     choose_seats();




//线程初始化
    pthread_t tid1;
    pthread_create(&tid1,NULL, read_card, NULL);
    pthread_detach(tid1);



//------第9个窗口-------------
	gtk_widget_show_all(window);
	gtk_main();//再一次从头开始，循环，一直刷新
	return 0;
}